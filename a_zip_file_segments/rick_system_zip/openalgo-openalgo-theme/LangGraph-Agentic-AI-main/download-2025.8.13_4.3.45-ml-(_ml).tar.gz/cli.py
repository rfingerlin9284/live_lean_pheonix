#!/usr/bin/env python3
import os
import sqlite3
import time
import subprocess
import json
import hashlib
import shutil
import requests
from datetime import datetime
from typing import TypedDict, List, Dict, Optional, Any
from urllib.parse import urlparse

# Data Processing
try:
    import PyPDF2
except ImportError:
    PyPDF2 = None
    print("Warning: PyPDF2 not installed - PDF processing will be unavailable")

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None
    print("Warning: BeautifulSoup4 not installed - HTML parsing will be limited")

# AI/ML Components
try:
    import chromadb
    from chromadb.utils import embedding_functions
except ImportError:
    chromadb = None
    embedding_functions = None
    print("Warning: ChromaDB not installed - vector database will be unavailable")

try:
    from langgraph.graph import END, StateGraph
    from langgraph.prebuilt import ToolNode as ToolExecutor
except ImportError:
    StateGraph = None
    ToolExecutor = None
    END = "END"
    print("Warning: LangGraph not installed - advanced workflow management will be unavailable")

try:
    from langchain_community.tools import Tool
except ImportError:
    print("Warning: LangChain not installed - using fallback Tool class")
    class Tool:
        def __init__(self, name: str, func: callable, description: str):
            self.name = name
            self.func = func
            self.description = description
        
        def run(self, *args, **kwargs):
            return self.func(*args, **kwargs)

try:
    from tavily import TavilyClient
except ImportError:
    TavilyClient = None
    print("Warning: Tavily not installed - web search will be limited")

# Headless Browser Automation
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    from selenium.webdriver.chrome.service import Service as ChromeService
    from webdriver_manager.chrome import ChromeDriverManager
except ImportError:
    webdriver = None
    By = None
    WebDriverWait = None
    EC = None
    ChromeOptions = None
    ChromeService = None
    ChromeDriverManager = None
    print("Warning: Selenium not installed - web automation will be unavailable")

# Optional Monitoring
try:
    import psutil
    import threading
    MONITORING_AVAILABLE = True
except ImportError:
    psutil = None
    threading = None
    MONITORING_AVAILABLE = False
    print("Warning: psutil/threading not available - system monitoring will be limited")

# Additional useful imports that might be needed
try:
    import numpy as np
except ImportError:
    np = None

try:
    import pandas as pd
except ImportError:
    pd = None

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

try:
    import seaborn as sns
except ImportError:
    sns = None

try:
    from sklearn.metrics.pairwise import cosine_similarity
except ImportError:
    cosine_similarity = None

# Define the AgentState type
class AgentState(TypedDict):
    messages: List[Dict[str, str]]
    task_type: Optional[str]
    current_step: Optional[str]
    context: Optional[Dict[str, Any]]
    results: Optional[List[str]]
    error: Optional[str]
    files_processed: Optional[List[str]]
    code_generated: Optional[str]
    web_data: Optional[Dict[str, Any]]
    analysis_results: Optional[Dict[str, Any]]

class SystemMonitor:
    """Optional system monitoring class"""
    def __init__(self):
        self.monitoring_active = False
        self.stats = {}
        
    def start_monitoring(self):
        """Start system monitoring if available"""
        if not MONITORING_AVAILABLE:
            return False
        
        self.monitoring_active = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        return True
    
    def _monitor_loop(self):
        """Monitor system resources"""
        while self.monitoring_active and psutil:
            try:
                self.stats = {
                    'cpu_percent': psutil.cpu_percent(interval=1),
                    'memory_percent': psutil.virtual_memory().percent,
                    'disk_usage': psutil.disk_usage('/').percent if os.path.exists('/') else 0,
                    'timestamp': datetime.utcnow().isoformat()
                }
                time.sleep(5)
            except Exception:
                break
    
    def stop_monitoring(self):
        """Stop system monitoring"""
        self.monitoring_active = False
    
    def get_stats(self):
        """Get current system stats"""
        return self.stats.copy()

class ActionLogger:
    def __init__(self, db_path="ai_agent_logs.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._init_db()

    def _init_db(self):
        """Initialize database tables with proper syntax"""
        # Create tables
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS action_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            session_id TEXT NOT NULL,
            tool_name TEXT NOT NULL,
            input_params TEXT,
            output TEXT,
            success INTEGER,
            latency REAL,
            token_usage INTEGER,
            additional_meta TEXT
        );
        
        CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            session_id TEXT NOT NULL,
            state_before TEXT,
            action_chosen TEXT,
            reasoning TEXT,
            outcome_score INTEGER
        );
        
        CREATE TABLE IF NOT EXISTS knowledge_base_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            document_id TEXT NOT NULL,
            source_type TEXT,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            UNIQUE(document_id)
        );
        
        CREATE TABLE IF NOT EXISTS system_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            session_id TEXT NOT NULL,
            cpu_percent REAL,
            memory_percent REAL,
            disk_usage REAL,
            active_processes INTEGER
        );
        """)
        
        # Create indexes separately
        self.conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_tool ON action_logs(tool_name);
        CREATE INDEX IF NOT EXISTS idx_session ON action_logs(session_id);
        CREATE INDEX IF NOT EXISTS idx_decisions_session ON decisions(session_id);
        CREATE INDEX IF NOT EXISTS idx_decisions_outcome ON decisions(outcome_score);
        CREATE INDEX IF NOT EXISTS idx_knowledge_doc ON knowledge_base_stats(document_id);
        CREATE INDEX IF NOT EXISTS idx_metrics_session ON system_metrics(session_id);
        """)
        
        self.conn.commit()

    def log_action(self, session_id: str, tool_name: str, input_params: Dict, output: str,
                  success: bool, latency: float, token_usage: int = None, meta: Dict = None):
        """Log tool executions"""
        try:
            self.conn.execute(
                """
                INSERT INTO action_logs (
                    timestamp, session_id, tool_name, input_params, 
                    output, success, latency, token_usage, additional_meta
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(),
                    session_id,
                    tool_name,
                    json.dumps(input_params),
                    str(output)[:2000],
                    int(success),
                    latency,
                    token_usage,
                    json.dumps(meta) if meta else None
                )
            )
            self.conn.commit()
        except Exception as e:
            print(f"Logging error: {e}")

    def log_decision(self, session_id: str, state_before: Dict, action_chosen: str, 
                    reasoning: str, outcome_score: int = None):
        """Log decision making process"""
        try:
            self.conn.execute(
                """
                INSERT INTO decisions (
                    timestamp, session_id, state_before, action_chosen, 
                    reasoning, outcome_score
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(),
                    session_id,
                    json.dumps(state_before),
                    action_chosen,
                    reasoning,
                    outcome_score
                )
            )
            self.conn.commit()
        except Exception as e:
            print(f"Decision logging error: {e}")

    def log_system_metrics(self, session_id: str, metrics: Dict):
        """Log system metrics"""
        try:
            self.conn.execute(
                """
                INSERT INTO system_metrics (
                    timestamp, session_id, cpu_percent, memory_percent, 
                    disk_usage, active_processes
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(),
                    session_id,
                    metrics.get('cpu_percent', 0),
                    metrics.get('memory_percent', 0),
                    metrics.get('disk_usage', 0),
                    metrics.get('active_processes', 0)
                )
            )
            self.conn.commit()
        except Exception as e:
            print(f"Metrics logging error: {e}")

    def get_session_stats(self, session_id: str) -> Dict:
        """Get statistics for a session"""
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT tool_name, COUNT(*), AVG(latency), SUM(success) FROM action_logs WHERE session_id = ? GROUP BY tool_name",
                (session_id,)
            )
            
            stats = {}
            for row in cursor.fetchall():
                tool_name, count, avg_latency, success_count = row
                stats[tool_name] = {
                    'total_calls': count,
                    'avg_latency': avg_latency,
                    'success_rate': success_count / count if count > 0 else 0
                }
            
            return stats
        except Exception as e:
            print(f"Stats retrieval error: {e}")
            return {}

    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()

class UltimateCoderAgent:
    def __init__(self):
        print("Initializing Ultimate Coder Agent...")
        
        # Core components
        self.logger = ActionLogger()
        self.session_id = hashlib.md5(str(time.time()).encode()).hexdigest()
        self.monitor = SystemMonitor()
        
        # API Configuration
        self.openrouter_api_key = os.getenv("OPENROUTER_API_KEY")
        self.model = "anthropic/claude-3.5-sonnet"  # More reliable model
        
        if not self.openrouter_api_key:
            print("ERROR: OPENROUTER_API_KEY not found in environment variables")
            raise ValueError("OpenRouter API key is required")
        
        # Initialize Tavily for web search
        if TavilyClient and os.getenv("TAVILY_API_KEY"):
            try:
                self.tavily = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))
                print("✓ Tavily web search initialized")
            except Exception as e:
                self.tavily = None
                print(f"⚠ Tavily initialization failed: {e}")
        else:
            self.tavily = None
            print("⚠ Tavily not available (missing API key or library)")
        
        # Initialize Selenium for web automation
        self.driver = None
        if webdriver and ChromeService and ChromeDriverManager:
            try:
                self.selenium_service = ChromeService(ChromeDriverManager().install())
                print("✓ Chrome WebDriver initialized")
            except Exception as e:
                print(f"⚠ Chrome WebDriver setup failed: {e}")
                self.selenium_service = None
        else:
            self.selenium_service = None
            print("⚠ Selenium not available")
        
        # Initialize ChromaDB for vector storage
        if chromadb:
            try:
                self.chroma_client = chromadb.Client()
                self.collection = self.chroma_client.get_or_create_collection(
                    name="agent_knowledge",
                    embedding_function=embedding_functions.DefaultEmbeddingFunction()
                )
                print("✓ ChromaDB vector database initialized")
            except Exception as e:
                self.chroma_client = None
                self.collection = None
                print(f"⚠ ChromaDB initialization failed: {e}")
        else:
            self.chroma_client = None
            self.collection = None
            print("⚠ ChromaDB not available")
        
        # Initialize tools and workflow
        self.tools = self._setup_tools()
        print(f"✓ Initialized {len(self.tools)} tools")
        
        if ToolExecutor:
            self.tool_executor = ToolExecutor(self.tools)
        else:
            self.tool_executor = None
        
        if StateGraph:
            self.workflow = self._setup_workflow()
            print("✓ LangGraph workflow initialized")
        else:
            self.workflow = None
            print("⚠ LangGraph not available - using simple mode")
        
        # Start monitoring if available
        if self.monitor.start_monitoring():
            print("✓ System monitoring started")
        
        print(f"✓ Agent initialized with session ID: {self.session_id}")

    def _call_openrouter(self, messages: List[Dict[str, str]], stream: bool = False, max_tokens: int = 4000):
        """Make API call to OpenRouter"""
        if not self.openrouter_api_key:
            raise RuntimeError("OpenRouter API key not found")
        
        try:
            payload = {
                "model": self.model,
                "messages": messages,
                "max_tokens": max_tokens,
                "temperature": 0.7,
                "stream": stream
            }
            
            response = requests.post(
                url="https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.openrouter_api_key}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://github.com/ultimate-coder-agent",
                    "X-Title": "Ultimate AI Coding Assistant",
                },
                json=payload,
                timeout=60
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="openrouter_api",
                input_params={"messages": messages, "model": self.model},
                output=str(e),
                success=False,
                latency=0
            )
            raise RuntimeError(f"OpenRouter API error: {str(e)}")

    def chat_completion(self, messages: List[Dict[str, str]], stream: bool = False, max_tokens: int = 4000):
        """Get chat completion from OpenRouter"""
        start_time = time.time()
        try:
            response = self._call_openrouter(messages, stream, max_tokens)
            
            if stream:
                def generate():
                    for chunk in response.iter_lines():
                        if chunk:
                            yield chunk
                return generate()
            else:
                result = response.json()
                
                if 'choices' not in result or not result['choices']:
                    raise RuntimeError("No response choices returned from API")
                
                content = result['choices'][0]['message']['content']
                
                self.logger.log_action(
                    session_id=self.session_id,
                    tool_name="chat_completion",
                    input_params={"messages": messages, "model": self.model},
                    output=content[:1000] + "..." if len(content) > 1000 else content,
                    success=True,
                    latency=time.time() - start_time,
                    meta={
                        "token_usage": result.get('usage', {}),
                        "model": self.model
                    }
                )
                return content
                
        except Exception as e:
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="chat_completion",
                input_params={"messages": messages},
                output=str(e),
                success=False,
                latency=time.time() - start_time
            )
            raise

    def _setup_tools(self) -> List[Tool]:
        """Define all available tools"""
        tools = []
        
        # File operations
        tools.extend([
            Tool(
                name="load_file",
                func=self._load_file,
                description="Load and process files (PDF, text, code) into the knowledge base"
            ),
            Tool(
                name="save_file",
                func=self._save_file,
                description="Save content to a file"
            ),
            Tool(
                name="list_files",
                func=self._list_files,
                description="List files in a directory"
            )
        ])
        
        # Web operations
        tools.extend([
            Tool(
                name="web_search",
                func=self._web_search,
                description="Search the web for information using Tavily"
            ),
            Tool(
                name="browse_web",
                func=self._browse_web,
                description="Browse and extract content from web pages"
            ),
            Tool(
                name="scrape_webpage",
                func=self._scrape_webpage,
                description="Advanced web scraping with Selenium"
            )
        ])
        
        # Code operations
        tools.extend([
            Tool(
                name="execute_code",
                func=self._execute_code,
                description="Execute code safely in various languages"
            ),
            Tool(
                name="analyze_code",
                func=self._analyze_code,
                description="Analyze code for issues, complexity, and suggestions"
            ),
            Tool(
                name="generate_code",
                func=self._generate_code,
                description="Generate code based on specifications"
            )
        ])
        
        # Data operations
        tools.extend([
            Tool(
                name="process_data",
                func=self._process_data,
                description="Process and analyze data files (CSV, JSON, etc.)"
            ),
            Tool(
                name="query_knowledge",
                func=self._query_knowledge,
                description="Query the vector knowledge base"
            )
        ])
        
        # System operations
        tools.extend([
            Tool(
                name="system_command",
                func=self._system_command,
                description="Execute system commands safely"
            ),
            Tool(
                name="get_system_info",
                func=self._get_system_info,
                description="Get system information and metrics"
            )
        ])
        
        return tools

    def _load_file(self, file_path: str) -> str:
        """Load and process a file into the knowledge base"""
        start_time = time.time()
        try:
            if not os.path.exists(file_path):
                return f"❌ File {file_path} not found"
            
            file_size = os.path.getsize(file_path)
            if file_size > 10 * 1024 * 1024:  # 10MB limit
                return f"❌ File {file_path} is too large ({file_size} bytes). Maximum size is 10MB."
            
            _, ext = os.path.splitext(file_path.lower())
            content = ""
            
            if ext == '.pdf' and PyPDF2:
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    for page_num, page in enumerate(reader.pages):
                        content += f"\n--- Page {page_num + 1} ---\n"
                        content += page.extract_text()
            elif ext in ['.txt', '.py', '.js', '.html', '.css', '.md', '.json', '.yaml', '.yml', '.xml']:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                    content = file.read()
            elif ext in ['.csv'] and pd is not None:
                df = pd.read_csv(file_path)
                content = f"CSV Data Summary:\n{df.describe()}\n\nFirst 10 rows:\n{df.head(10).to_string()}"
            else:
                return f"❌ Unsupported file type: {ext}"
            
            # Store in vector database if available
            if self.collection:
                doc_id = hashlib.md5(file_path.encode()).hexdigest()
                chunks = self._chunk_text(content)
                
                for i, chunk in enumerate(chunks):
                    self.collection.add(
                        documents=[chunk],
                        ids=[f"{doc_id}_chunk_{i}"],
                        metadatas=[{
                            "file_path": file_path,
                            "type": "file",
                            "extension": ext,
                            "chunk_index": i,
                            "total_chunks": len(chunks)
                        }]
                    )
            
            result = f"✅ Successfully loaded {file_path}\n"
            result += f"   ?? Size: {len(content):,} characters\n"
            result += f"   ?? Type: {ext}\n"
            result += f"   ⏱️ Processing time: {time.time() - start_time:.2f}s"
            
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="load_file",
                input_params={"file_path": file_path},
                output=result,
                success=True,
                latency=time.time() - start_time
            )
            
            return result
            
        except Exception as e:
            error_msg = f"❌ Error loading file {file_path}: {str(e)}"
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="load_file",
                input_params={"file_path": file_path},
                output=error_msg,
                success=False,
                latency=time.time() - start_time
            )
            return error_msg

    def _chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """Split text into overlapping chunks"""
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at sentence or word boundaries
            if end < len(text):
                for i in range(end, start + chunk_size - 200, -1):
                    if text[i] in '.!?\n':
                        end = i + 1
                        break
                else:
                    # Fallback to word boundary
                    for i in range(end, start + chunk_size - 100, -1):
                        if text[i] == ' ':
                            end = i
                            break
            
            chunks.append(text[start:end].strip())
            start = max(start + 1, end - overlap)
        
        return [chunk for chunk in chunks if chunk.strip()]

    def _save_file(self, file_path: str, content: str) -> str:
        """Save content to a file"""
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return f"✅ Successfully saved {len(content)} characters to {file_path}"
            
        except Exception as e:
            return f"❌ Error saving file {file_path}: {str(e)}"

    def _list_files(self, directory: str = ".", pattern: str = "*") -> str:
        """List files in a directory"""
        try:
            import glob
            
            if not os.path.exists(directory):
                return f"❌ Directory {directory} not found"
            
            search_pattern = os.path.join(directory, pattern)
            files = glob.glob(search_pattern)
            
            if not files:
                return f"?? No files found matching '{pattern}' in {directory}"
            
            result = f"?? Files in {directory} matching '{pattern}':\n"
            for file in sorted(files):
                if os.path.isfile(file):
                    size = os.path.getsize(file)
                    modified = datetime.fromtimestamp(os.path.getmtime(file)).strftime("%Y-%m-%d %H:%M")
                    result += f"   ?? {file} ({size:,} bytes, modified: {modified})\n"
                elif os.path.isdir(file):
                    result += f"   ?? {file}/\n"
            
            return result
            
        except Exception as e:
            return f"❌ Error listing files: {str(e)}"

    def _web_search(self, query: str, max_results: int = 5) -> str:
        """Search the web using Tavily"""
        start_time = time.time()
        try:
            if not self.tavily:
                return "❌ Web search not available - Tavily client not initialized"
            
            results = self.tavily.search(query, max_results=max_results)
            
            if not results.get('results'):
                return f"?? No search results found for: {query}"
            
            search_output = f"?? Web search results for: '{query}'\n\n"
            
            for i, result in enumerate(results['results'], 1):
                title = result.get('title', 'No title')
                url = result.get('url', 'No URL')
                content = result.get('content', 'No content')[:300] + "..."
                
                search_output += f"{i}. **{title}**\n"
                search_output += f"   ?? {url}\n"
                search_output += f"   ?? {content}\n\n"
            
            # Store results in knowledge base
            if self.collection:
                doc_id = hashlib.md5(f"search_{query}_{int(time.time())}".encode()).hexdigest()
                self.collection.add(
                    documents=[json.dumps(results['results'])],
                    ids=[doc_id],
                    metadatas=[{
                        "type": "web_search",
                        "query": query,
                        "timestamp": datetime.utcnow().isoformat()
                    }]
                )
            
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="web_search",
                input_params={"query": query, "max_results": max_results},
                output=search_output[:1000] + "..." if len(search_output) > 1000 else search_output,
                success=True,
                latency=time.time() - start_time
            )
            
            return search_output
            
        except Exception as e:
            error_msg = f"❌ Web search error: {str(e)}"
            self.logger.log_action(
                session_id=self.session_id,
                tool_name="web_search",
                input_params={"query": query},
                output=error_msg,
                success=False,
                latency=time.time() - start_time
            )
            return error_msg

    def _browse_web(self, url: str) -> str:
        """Browse and extract content from a web page"""
        start_time = time.time()
        try:
            # Validate URL
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                return f"❌ Invalid URL: {url}"
            
            # Simple HTTP request first
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
            response.raise_for_status()
            
            content = response.text
            
            # Parse with BeautifulSoup if available
            if BeautifulSoup:
                soup = BeautifulSoup(content, 'html.parser')
                
                # Extract title
                title = soup.title.string if soup.title else "No title"
                
                # Remove script and style elements
                for script in soup(["script", "style", "nav", "header", "footer"]):
                    script.decompose()
                
                # Get text content
                text_content = soup.get_text()
                
                # Clean up text
                lines = [line.strip() for line in text_content.splitlines()]
                text_content = '\n'.join([line for line in lines if line])
                
                result = f"?? Successfully browsed: {url}\n"
                result += f"?? Title: {title}\n"
                result += f"?? Content length: {len(text_content):,} characters\n\n"
                result += f"?? Content preview:\n{text_content[:1000]}..."
                
                # Store in knowledge base
                if self.collection:
                    doc_id = hashlib.md5(url.encode()).hexdigest()
                    chunks = self._chunk_text(text_content)
                    
                    for i, chunk in enumerate(chunks):
                        self.collection.add(
                            documents=[chunk],
                            ids=[f"{doc_id}_chunk_{i}"],
                            metadatas=[{
                                "url": url,
                                "title": title,
                                "type": "webpage",
                                "chunk_index": i,
                                "total_chunks": len(chunks)
                            }]
                        )
                
                self.logger.log_action(
                    session_id=self.session_id,
                    tool_name="browse_web",
                    input_params={"url": url},
                    output=result,
                    success=True,
                    latency=time.time() - start_time
                )
                
           try:

    # some code

finally:

    result = f"""?? Raw HTML

    <html>

    <body>{some_var}</body>

    </html>

    """

    print(result)