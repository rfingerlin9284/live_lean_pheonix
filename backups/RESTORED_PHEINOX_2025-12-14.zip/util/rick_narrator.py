#!/usr/bin/env python3
"""
Minimal RickNarrator for testing: provide generate_commentary that returns a short string.
"""
class RickNarrator:
    def __init__(self):
        pass

    def generate_commentary(self, *args, **kwargs):
        # Very small, human-friendly commentary
        return "Automated decision logged."
