# AUTO-GENERATED WRAPPER
from CONSOLIDATED_STRATEGIES.consolidated_core_strategies import CryptoBreakoutStrategy

# Re-export CryptoBreakoutStrategy
__all__ = ['CryptoBreakoutStrategy']
