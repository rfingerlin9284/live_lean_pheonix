from .momentum_signals import generate_signal
