#!/usr/bin/env python3
"""RICK PHOENIX - OANDA Trading Engine (Single Canonical Engine)

This is the ONLY supported engine entrypoint.

Key behaviors:
- Uses momentum signals from `core/momentum_signals.py`
- Uses the canonical OANDA connector: `brokers/oanda_connector.py`
- Two-step stop method (break-even -> tight trail)
- Optional TP (disabled by default)
- Optional incremental scale-out (partial closes)

PIN: 841921
"""

# NOTE:
# This file is kept only for backwards-compatibility with old launch scripts.
# The ONLY canonical engine implementation lives in `oanda/oanda_trading_engine.py`.

import os as _os
import runpy as _runpy
import sys as _sys

_REPO_ROOT = _os.path.abspath(_os.path.dirname(__file__))
_sys.path.insert(0, _REPO_ROOT)

# If executed directly, delegate to canonical engine.
if __name__ == '__main__':
    _runpy.run_path(_os.path.join(_REPO_ROOT, 'oanda', 'oanda_trading_engine.py'), run_name='__main__')
    raise SystemExit(0)

# If imported, expose the canonical engine class.
from oanda.oanda_trading_engine import OandaTradingEngine  # noqa: F401,E402

# ---------------------------------------------------------------------------
# Legacy engine source (archived; intentionally not executed)
# ---------------------------------------------------------------------------
_LEGACY_ENGINE_SOURCE = r'''
import os
import sys
import asyncio
import logging
import json
from pathlib import Path
from typing import Dict, Optional

# Ensure repo root in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from foundation.rick_charter import RickCharter
from foundation.agent_charter import AgentCharter
from brokers.oanda_connector import OandaConnector
from util.terminal_display import TerminalDisplay
from util.narration_logger import log_narration
from util.position_police import _rbz_force_min_notional_position_police
from util.alert_notifier import send_system_alert

from core.momentum_signals import generate_signal


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('oanda_engine')


class OandaTradingEngine:
    def __init__(self, environment: Optional[str] = None):
        AgentCharter.enforce()
        if not getattr(RickCharter, 'PIN', None) == 841921:
            raise PermissionError('Invalid Charter PIN')

        self.display = TerminalDisplay()
        if environment is None:
            environment = os.getenv('RICK_ENV') or os.getenv('TRADING_ENVIRONMENT') or 'practice'
        self.environment = environment

        # Canonical connector (practice token is hardcoded in the connector in this repo snapshot)
        self.oanda = OandaConnector(pin=841921, environment=environment)

        self.toggle_paths = [
            Path(os.getenv('PHX_TOGGLES_PATH') or os.getenv('TOGGLES_PATH') or 'PHOENIX_CLEAN_CUT/config/toggles.json'),
            Path('config/toggles.json'),
        ]
        self.default_toggles = {
            "no_simulation_mode": True,
            "tight_trailing": True,
            "two_step_sl": True,
            "tp_for_scalps": False,
            "tp_for_swings": False,
            "be_trigger_pips": 6,
            "trail_trigger_pips": 12,
            "trail_distance_pips": 6,
            "tight_trail_distance_pips": 3,
            "alert_on_auth": True,
            "scale_out_enabled": True,
            "scale_out_levels": [
                {"pips": 8, "fraction": 0.33},
                {"pips": 16, "fraction": 0.33},
            ],
        }
        self.toggles = self._load_toggles()
        self._auth_reported_ok = False
        self._auth_reported_fail = False

        # Engine constants
        self.MIN_CONFIDENCE = 0.55
        self.MAX_POSITIONS = 12
        self.STOP_LOSS_PIPS = 10
        self.TAKE_PROFIT_PIPS = 32
        self.TRAILING_START_PIPS = 3
        self.TRAILING_DIST_PIPS = 5
        self.TRADING_PAIRS = ['EUR_USD', 'GBP_USD', 'USD_JPY', 'AUD_USD', 'USD_CAD']

        self.running = False
        self.active_positions: Dict[str, dict] = {}
        self._scale_out_done: Dict[str, set] = {}

        self._announce()
        self._check_auth_guard()

    def _load_toggles(self) -> Dict:
        for path in self.toggle_paths:
            try:
                if path.is_file():
                    return {**self.default_toggles, **json.loads(path.read_text())}
            except Exception as e:
                logger.warning(f"Failed to load toggles from {path}: {e}")
        return self.default_toggles.copy()

    def _check_auth_guard(self):
        ok, msg = self.oanda.check_authorization()
        if ok:
            if self.toggles.get("alert_on_auth", True) and not self._auth_reported_ok:
                try:
                    send_system_alert("OANDA connected ✅", msg)
                except Exception:
                    logger.debug('Auth success alert failed', exc_info=True)
            self._auth_reported_ok = True
            self._auth_reported_fail = False
            return

        if not self._auth_reported_fail and self.toggles.get("alert_on_auth", True):
            try:
                send_system_alert("❌ Unauthorized 401 — check OANDA token", msg, level="ERROR")
            except Exception:
                logger.debug('Auth failure alert failed', exc_info=True)
        self._auth_reported_fail = True
        if self.toggles.get("no_simulation_mode", True):
            raise SystemExit("Auth failed — refusing to run (no_simulation_mode=true).")

    def _announce(self):
        self.display.clear_screen()
        self.display.header('RBOTZILLA Consolidated', f'Env: {self.environment} | PIN: {getattr(RickCharter, "PIN", "N/A")}')
        try:
            log_narration(
                event_type="PROFILE_STATUS",
                details={
                    "description": "Balanced profile applied",
                    "min_expected_pnl_usd": getattr(RickCharter, 'MIN_EXPECTED_PNL_USD', None),
                    "min_notional_usd": getattr(RickCharter, 'MIN_NOTIONAL_USD', None),
                    "max_margin_utilization_pct": getattr(RickCharter, 'MAX_MARGIN_UTILIZATION_PCT', None),
                },
                symbol='SYSTEM',
                venue='oanda',
            )
        except Exception:
            pass

    def _run_police(self):
        try:
            _rbz_force_min_notional_position_police(
                account_id=self.oanda.account_id,
                token=self.oanda.api_token,
                api_base=self.oanda.api_base,
            )
        except Exception as e:
            logger.warning('Position police error: %s', e)

    async def run(self):
        self.running = True
        while self.running:
            try:
                self.toggles = self._load_toggles()
                self._check_auth_guard()

                trades = self.oanda.get_trades() or []
                self.active_positions = {t['id']: t for t in trades if 'id' in t}
                self.display.info('Active Positions', str(len(self.active_positions)))

                self._run_police()

                if len(self.active_positions) < self.MAX_POSITIONS:
                    for symbol in self.TRADING_PAIRS:
                        if any((t.get('instrument') or t.get('symbol')) == symbol for t in trades):
                            continue
                        candles = self.oanda.get_historical_data(symbol, count=100, granularity='M15')
                        result = generate_signal(symbol, candles)
                        if isinstance(result, tuple):
                            sig = result[0]
                            conf = result[1] if len(result) > 1 else 0.0
                        else:
                            sig, conf = result, 0.0
                        if sig and conf >= self.MIN_CONFIDENCE:
                            await self._open_trade(symbol, sig, conf)
                            await asyncio.sleep(1)

                for trade in trades:
                    await self._manage_trade(trade)

                await asyncio.sleep(30)
            except Exception as e:
                logger.error('Engine main loop error: %s', e)
                await asyncio.sleep(5)

    async def _open_trade(self, symbol: str, direction: str, confidence: float):
        prices = self.oanda.get_live_prices([symbol])
        if not prices or symbol not in prices:
            return
        snap = prices[symbol]
        bid = snap.get('bid')
        ask = snap.get('ask')
        entry = ask if direction == 'BUY' else bid
        if entry is None:
            return
        try:
            entry = float(entry)
        except Exception:
            return

        pip = 0.01 if 'JPY' in symbol else 0.0001
        sl = entry - (self.STOP_LOSS_PIPS * pip) if direction == 'BUY' else entry + (self.STOP_LOSS_PIPS * pip)

        strategy_name = os.getenv('ENGINE_STRATEGY', 'momentum')
        is_scalp = strategy_name in {"wolfpack_ema_trend", "fvg_breakout", "scalp"}
        use_tp = self.toggles.get('tp_for_swings', False) if not is_scalp else self.toggles.get('tp_for_scalps', False)
        tp = None
        if use_tp:
            tp = entry + (self.TAKE_PROFIT_PIPS * pip) if direction == 'BUY' else entry - (self.TAKE_PROFIT_PIPS * pip)

        min_notional = getattr(RickCharter, 'MIN_NOTIONAL_USD', 15000)
        if symbol.startswith('USD'):
            units = int(min_notional * 1.05)
        else:
            units = int((min_notional * 1.05) / max(entry, 1e-9))
        units = ((units // 100) + 1) * 100
        units = units if direction == 'BUY' else -units

        base_ccy, quote_ccy = (symbol.split('_', 1) + [''])[:2]
        if quote_ccy == 'USD':
            risk_usd = abs(entry - sl) * abs(units)
            reward_usd = abs(tp - entry) * abs(units) if tp is not None else 0.0
            notional_usd = abs(units) * entry
        elif base_ccy == 'USD':
            risk_usd = (abs(entry - sl) * abs(units)) / max(entry, 1e-9)
            reward_usd = ((abs(tp - entry) * abs(units)) / max(entry, 1e-9)) if tp is not None else 0.0
            notional_usd = abs(units)
        else:
            risk_usd = 0.0
            reward_usd = 0.0
            notional_usd = None

        tp_text = f"TP: {tp:.5f} (+${reward_usd:.2f})" if tp is not None else "TP: -- (disabled)"
        self.display.info('Placing', f"{symbol} {direction} | SL: {sl:.5f} (-${risk_usd:.2f}) | {tp_text}")
        try:
            log_narration(event_type='TRADE_SIGNAL', details={'symbol': symbol, 'direction': direction, 'confidence': confidence})
        except Exception:
            pass

        result = self.oanda.place_oco_order(symbol, entry, sl, tp, units)
        if result.get('success'):
            order_id = result.get('order_id')
            self.display.alert(f"✅ Order placed! Order ID: {order_id}", 'SUCCESS')
            target_text = f"{tp:.5f}" if tp is not None else "--"
            notional_text = f"${notional_usd:,.0f}" if isinstance(notional_usd, (int, float)) else "--"
            self.display.trade_open(
                symbol,
                direction,
                entry,
                f"Stop: {sl:.5f} | Target: {target_text} | Size: {abs(units):,} units | Notional: {notional_text}",
            )
            try:
                log_narration(
                    event_type='TRADE_OPENED',
                    details={
                        'symbol': symbol,
                        'entry_price': entry,
                        'stop_loss': sl,
                        'take_profit': tp,
                        'stop_loss_usd': round(risk_usd, 2),
                        'take_profit_usd': round(reward_usd, 2),
                        'notional_usd': round(notional_usd, 2) if isinstance(notional_usd, (int, float)) else None,
                    },
                )
            except Exception:
                pass
        else:
            self.display.error('Order failed: ' + str(result.get('error')))

    async def _manage_trade(self, trade):
        try:
            is_long = float(trade.get('currentUnits', trade.get('units', 0))) > 0
            trade_id = str(trade.get('id') or '')
            entry = float(trade.get('price') or trade.get('entryPrice') or 0)

            sl_order = trade.get('stopLossOrder') or {}
            price_val = sl_order.get('price') if sl_order else None
            current_sl = float(price_val) if price_val is not None else None

            symbol = trade.get('instrument') or trade.get('symbol')
            if not symbol:
                return

            prices = self.oanda.get_live_prices([symbol])
            if not prices or symbol not in prices:
                return
            snap = prices[symbol]
            curr = snap.get('bid') if is_long else snap.get('ask')
            if curr is None:
                return
            curr = float(curr)

            pip = 0.01 if 'JPY' in symbol else 0.0001
            profit_pips = (curr - entry) / pip if is_long else (entry - curr) / pip

            # Optional scale-out (incremental partial closes)
            try:
                if self.toggles.get('scale_out_enabled', True) and trade_id:
                    done = self._scale_out_done.setdefault(trade_id, set())
                    levels = self.toggles.get('scale_out_levels') or []
                    sane_levels = []
                    for i, lvl in enumerate(levels):
                        if not isinstance(lvl, dict):
                            continue
                        p = lvl.get('pips')
                        f = lvl.get('fraction')
                        if p is None or f is None:
                            continue
                        try:
                            p = float(p)
                            f = float(f)
                        except Exception:
                            continue
                        if p > 0 and 0 < f < 1:
                            sane_levels.append((i, p, f))

                    if sane_levels:
                        abs_units = int(abs(float(trade.get('currentUnits', trade.get('units', 0)))))
                        for idx, pips_trigger, fraction in sane_levels:
                            if idx in done:
                                continue
                            if profit_pips >= pips_trigger and abs_units >= 2:
                                close_units = int(abs_units * fraction)
                                close_units = max(1, (close_units // 100) * 100)
                                if close_units >= abs_units:
                                    continue
                                resp = self.oanda.close_trade(trade_id, close_units)
                                if resp and resp.get('success'):
                                    done.add(idx)
                                    self.display.info('Scale-out', f"{symbol}: closed {close_units} units at +{profit_pips:.1f} pips")
            except Exception:
                pass

            be_trigger = self.toggles.get('be_trigger_pips', self.TRAILING_START_PIPS)
            trail_trigger = self.toggles.get('trail_trigger_pips', self.TRAILING_START_PIPS)
            trail_distance = self.toggles.get('tight_trail_distance_pips', self.TRAILING_DIST_PIPS) if self.toggles.get('tight_trailing', True) else self.toggles.get('trail_distance_pips', self.TRAILING_DIST_PIPS)

            # Step 1: move to break-even
            if self.toggles.get('two_step_sl', True) and profit_pips >= be_trigger:
                be_sl = entry
                if current_sl is None or (is_long and be_sl > current_sl) or (not is_long and be_sl < current_sl):
                    self.display.info('SL to BE', f"{symbol}: {current_sl if current_sl is not None else 0:.5f} -> {be_sl:.5f}")
                    self.oanda.set_trade_stop(trade.get('id'), be_sl)
                    current_sl = be_sl

            # Step 2: tight trailing once trigger reached
            if profit_pips >= trail_trigger:
                new_sl = curr - (trail_distance * pip) if is_long else curr + (trail_distance * pip)
                if current_sl is None or (is_long and new_sl > current_sl) or (not is_long and new_sl < current_sl):
                    self.display.info('Trailing', f"{symbol}: {current_sl if current_sl is not None else 0:.5f} -> {new_sl:.5f}")
                    self.oanda.set_trade_stop(trade.get('id'), new_sl)
        except Exception:
            pass


def _autostop_previous_instances():
    try:
        import subprocess
        import time

        result = subprocess.run(['pgrep', '-f', 'oanda_trading_engine.py'], capture_output=True, text=True)
        existing_pids = [pid for pid in result.stdout.strip().split('\n') if pid and pid != str(os.getpid())]
        if existing_pids:
            print(f"🔄 Stopping {len(existing_pids)} existing OANDA engine(s)...")
            subprocess.run(['pkill', '-f', 'python3.*oanda_trading_engine.py'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(2)
            print("✅ Ready to start")
    except Exception as e:
        logger.warning(f"Could not check for existing instances: {e}")


if __name__ == '__main__':
    _autostop_previous_instances()
    engine = OandaTradingEngine(environment=os.getenv('RICK_ENV', 'practice'))
    try:
        asyncio.run(engine.run())
    except KeyboardInterrupt:
        print('\nStopped')

# Aggressive Money Machine - Dynamic Sizing imports
try:
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from risk.dynamic_sizing import DynamicSizing, PositionSizeResult
    from config.aggressive_machine_config import CONFIG as AGGRESSIVE_CONFIG
    AGGRESSIVE_MODE_AVAILABLE = True
except ImportError as e:
    AGGRESSIVE_MODE_AVAILABLE = False
    AGGRESSIVE_CONFIG = None
    print(f"⚠️  Aggressive Money Machine not available: {e}")

# Wolf Pack imports
try:
    from wolf_packs.orchestrator import WolfPackOrchestrator
    WOLF_PACK_AVAILABLE = True
except ImportError:
    WOLF_PACK_AVAILABLE = False
    print("⚠️  Hive Mind not available - running without swarm coordination")

# Momentum & Trailing imports (extracted from rbotzilla_golden_age.py)
try:
    from util.momentum_trailing import MomentumDetector, SmartTrailingSystem
    MOMENTUM_SYSTEM_AVAILABLE = True
except ImportError:
    MOMENTUM_SYSTEM_AVAILABLE = False
    print("⚠️  Momentum/Trailing system not available")

class OandaTradingEngine:
    """
    RBOTzilla Charter-Compliant OANDA Trading Engine
    - Environment agnostic (practice/live determined by API token/endpoint only)
    - Immutable OCO orders (3:1 R:R minimum)
    - Full narration logging to JSONL
    - ML regime detection and signal analysis
    - Rick Hive Mind coordination
    - Sub-300ms execution tracking
    """
    
    def __init__(self, environment='practice'):
        """
        Initialize Trading Engine
        
        Args:
            environment: 'practice' or 'live' (default: practice)
                        Only difference is API endpoint and token used
        """
        # Validate Charter PIN
        if not RickCharter.validate_pin(841921):
            raise PermissionError("Invalid Charter PIN - cannot initialize trading engine")
        
        self.display = TerminalDisplay()
        self.environment = environment
        
        # Initialize OANDA connector: environment determines endpoint only
        self.oanda = OandaConnector(environment=environment)
        env_label = "PRACTICE" if environment == 'practice' else "LIVE"
        self.display.success(f"✅ {env_label} API connected")
        print(f"   Account: {self.oanda.account_id}")
        print(f"   Endpoint: {self.oanda.api_base}")
        
        # Initialize Rick's narration system
        self.narrator = RickNarrator()
        
        # Initialize ML Intelligence if available
        if ML_AVAILABLE:
            self.regime_detector = RegimeDetector(pin=841921)
            self.display.success("✅ ML Regime Detection loaded")
        else:
            self.regime_detector = None
        
        # Initialize Hive Mind if available
        if HIVE_AVAILABLE:
            self.hive_mind = RickHiveMind()
            self.display.success("✅ Hive Mind connected")
        else:
            self.hive_mind = None
        
        # Initialize Momentum System if available
        if MOMENTUM_SYSTEM_AVAILABLE:
            self.momentum_detector = MomentumDetector()
            self.trailing_system = SmartTrailingSystem()
            self.display.success("✅ Momentum/Trailing system loaded")
        else:
            self.momentum_detector = None
            self.trailing_system = None
        
        # Initialize Strategy Aggregator (combines 5 prototype strategies)
        try:
            from util.strategy_aggregator import StrategyAggregator
            self.strategy_aggregator = StrategyAggregator(signal_vote_threshold=2)
            self.display.success("✅ Strategy Aggregator loaded (5 prototype strategies)")
        except ImportError:
            self.strategy_aggregator = None
            self.display.warning("⚠️  Strategy Aggregator not available")
        
        # Initialize Quantitative Hedge Engine (correlation-based hedging)
        try:
            from util.quant_hedge_engine import QuantHedgeEngine
            self.hedge_engine = QuantHedgeEngine()
            self.active_hedges = {}  # Track active hedge positions
            self.display.success("✅ Quantitative Hedge Engine loaded")
        except ImportError:
            self.hedge_engine = None
            self.active_hedges = {}
            self.display.warning("⚠️  Hedge Engine not available")
        
        # Charter-compliant trading parameters
        self.charter = RickCharter
        # Create a risk manager instance (optional)
        try:
            from util.risk_manager import RiskManager
            self.risk_manager = RiskManager()
        except Exception:
            self.risk_manager = None
        # If the execution gate exists, let it share the same risk manager instance
        try:
            import util.execution_gate as eg
            if self.risk_manager is not None:
                eg._risk_manager = self.risk_manager
        except Exception:
            pass

        # ------------------------------------------------------------------
        # STRATEGY ADVISOR: family-aware preference + performance tracking
        # ------------------------------------------------------------------
        try:
            from util.strategy_advisor import StrategyAdvisor
            raw_fams = os.getenv('RBZ_PREF_STRATEGY_FAMILIES', '')
            if raw_fams:
                fams = [f.strip().lower() for f in raw_fams.split(',') if f.strip()]
            else:
                fams = None
            self.strategy_advisor = StrategyAdvisor(preferred_families=fams)
        except Exception as e:
            self.strategy_advisor = None
            self.display.warning(f"⚠️  StrategyAdvisor not available: {e}")
        
        # ========================================================================
        # MARGIN & CORRELATION GUARDIAN GATES (NEW)
        # ========================================================================
        # Get account NAV for gate calculations
        # Use default NAV for bootstrap - will be updated from API calls
        account_nav = 2000.0  # Default OANDA practice account NAV
        try:
            if hasattr(self.oanda, 'get_account_info'):
                account_info = self.oanda.get_account_info()
                account_nav = float(account_info.get('NAV', 2000.0))
        except Exception as e:
            self.display.warn(f"⚠️  Could not fetch account NAV: {e}, using default $2000")
        
        self.gate = MarginCorrelationGate(account_nav=account_nav)
        self.current_positions = []  # Track positions for gate monitoring
        self.pending_orders = []      # Track pending orders for gate monitoring
        self.display.success("🛡️  Margin & Correlation Guardian Gates ACTIVE")
        
        # ========================================================================
        # AGGRESSIVE MONEY MACHINE - Dynamic Sizing & Wolf Packs (3-Year Growth Plan)
        # ========================================================================
        self.dynamic_sizer = None
        self.wolf_pack_orchestrator = None
        self.aggressive_config = AGGRESSIVE_CONFIG
        
        if AGGRESSIVE_MODE_AVAILABLE and self.aggressive_config:
            try:
                self.dynamic_sizer = DynamicSizing(pin=841921, account_balance=account_nav)
                self.display.success("✅ Dynamic Sizing Engine ACTIVE (Kelly Criterion)")
                
                # Load aggressive position sizing settings
                sizing_config = self.aggressive_config.get('position_sizing', {})
                self.risk_per_trade_pct = sizing_config.get('risk_per_trade_pct', 0.02)  # 2% risk
                self.kelly_scaling = sizing_config.get('scaling_rule', 'kelly_criterion')
                self.aggressive_scaling_enabled = sizing_config.get('aggressive_mode', {}).get('enabled', True)
                
                # Wolf pack regime settings
                self.wolf_pack_settings = self.aggressive_config.get('wolf_packs', {})
                self.display.success(f"✅ Wolf Pack Strategies loaded ({len(self.wolf_pack_settings)} regimes)")
                
                # Growth targets from 3-year plan
                self.growth_targets = self.aggressive_config.get('targets', {})
                
            except Exception as e:
                self.display.warning(f"⚠️  Aggressive Money Machine init failed: {e}")
                self.dynamic_sizer = None
        else:
            self.risk_per_trade_pct = 0.02
            self.aggressive_scaling_enabled = False
            self.wolf_pack_settings = {}
            self.growth_targets = {}
        
        # Sync positions from OANDA on startup
        self._sync_positions_from_oanda()
        
        # ALL AVAILABLE OANDA FOREX PAIRS (from env_new.env)
        # Major USD pairs + Major crosses + Commodity currencies
        self.trading_pairs = [
            # Major USD pairs (highest liquidity)
            'EUR_USD', 'GBP_USD', 'USD_JPY', 'USD_CHF', 'AUD_USD', 'USD_CAD', 'NZD_USD',
            # Major crosses (no USD)
            'EUR_GBP', 'EUR_JPY', 'GBP_JPY', 'AUD_JPY', 'CHF_JPY',
            # European crosses
            'EUR_CHF', 'GBP_CHF',
            # Commodity currency crosses
            'AUD_CHF', 'NZD_CHF', 'EUR_AUD', 'GBP_AUD'
        ]
        
        self.min_trade_interval = 300  # 5 minutes (MICRO TRADING DISABLED - Minimum 5min enforced)
        
        # IMMUTABLE RISK MANAGEMENT (Charter Section 3.2)
        # PRACTICE MODE: Lower minimums to allow trading with smaller accounts
        if self.environment == 'practice':
            self.min_notional_usd = 1000  # $1,000 minimum for PRACTICE accounts
            self.position_size = 1000  # Smaller position for practice
        else:
            self.min_notional_usd = self.charter.MIN_NOTIONAL_USD  # $15,000 minimum (Charter immutable)
            self.position_size = 14000  # Base size (adjusted per pair to meet minimums)
        
        # Use STEP 1 surgeon stop as the charter risk distance
        self.initial_stop_pips = 10  # Defined from Friday defaults
        self.stop_loss_pips = self.initial_stop_pips   # 10 pips initial hard SL
        self.take_profit_pips = 64                     # keeps R:R well above 3.2:1
        self.min_rr_ratio = self.charter.MIN_RISK_REWARD_RATIO  # 3.2
        self.max_daily_loss = abs(self.charter.DAILY_LOSS_BREAKER_PCT)  # 5%
        
        # State tracking
        self.active_positions = {}
        self.total_trades = 0
        self.wins = 0
        self.losses = 0
        self.total_pnl = 0.0
        self.is_running = False
        self.session_start = datetime.now(timezone.utc)

        # TradeManager settings
        # Only consider converting TP -> trailing SL after 60 seconds
        self.min_position_age_seconds = 60
        # Hive consensus threshold to trigger TP cancellation
        hive_conf = float(os.getenv('HIVE_TRIGGER_CONFIDENCE', '0.60'))
        dev_mode = os.getenv('RICK_DEV_MODE', '0') == '1'
        try:
            from foundation.rick_charter import RickCharter as _RC
            charter_min = getattr(_RC, 'HIVE_TRIGGER_CONFIDENCE_MIN', 0.80)
            if charter_min is not None and not dev_mode and hive_conf < charter_min:
                hive_conf = charter_min
        except Exception:
            pass
        self.hive_trigger_confidence = hive_conf
        self.hive_trigger_enforced_by_charter = (not dev_mode and float(os.getenv('HIVE_TRIGGER_CONFIDENCE', '0.60')) < hive_conf)
        
        # Narration logging
        log_narration(
            event_type="ENGINE_START",
            details={
                "pin": "841921",
                "environment": environment,
                "charter_compliant": True,
                "ml_enabled": ML_AVAILABLE,
                "hive_enabled": HIVE_AVAILABLE,
                "min_rr_ratio": self.min_rr_ratio
            },
            symbol="SYSTEM",
            venue="oanda"
        )
        
        self._display_startup()

        # Two-step "surgeon" stop-loss parameters
        # STEP 1: small hard stop, then move SL to BE+lock once trade reaches 1R
        # STEP 2: after 2R or strong Hive/Momentum, cancel TP and convert to trailing SL
        self.initial_stop_pips = 10.0          # initial hard SL distance in pips
        self.step1_rr_trigger = 1.0            # at 1R -> move SL to BE+lock
        self.step1_lock_in_pips = 2.0          # lock in 2 pips on STEP 1
        self.step2_rr_trigger = 2.0            # at 2R or strong consensus -> cancel TP & trail
        self.min_trailing_lock_pips = 4.0      # min locked profit when trailing

        # Toggle: enable/disable STEP 2 (TP cancel + trailing SL)
        # RBZ_ENABLE_STEP2_TRAILING = "1" → ON (default)
        # RBZ_ENABLE_STEP2_TRAILING = "0" → OFF (keep single SL/TP after STEP 1)
        self.enable_step2_trailing = os.getenv("RBZ_ENABLE_STEP2_TRAILING", "1") == "1"

        # Display toggle status at startup
        if hasattr(self, 'display') and hasattr(self.display, 'info'):
            self.display.info(
                "Step 2 Trailing",
                "ENABLED" if self.enable_step2_trailing else "DISABLED",
                Colors.BRIGHT_GREEN if self.enable_step2_trailing else Colors.BRIGHT_BLACK
            )
    
    def _display_startup(self):
        """Display startup screen with Charter compliance info"""
        self.display.clear_screen()
        env_label = "PRACTICE" if self.environment == 'practice' else "LIVE"
        env_color = Colors.BRIGHT_YELLOW if self.environment == 'practice' else Colors.BRIGHT_RED
        
        self.display.header(
            f"🤖 RBOTzilla TRADING ENGINE ({env_label})",
            f"Charter-Compliant OANDA | PIN: 841921 | {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
        
        self.display.section("CHARTER COMPLIANCE STATUS")
        self.display.info("PIN Validated", "841921 ✅", Colors.BRIGHT_GREEN)
        self.display.info("Charter Version", "RBOTzilla UNI Phase 9", Colors.BRIGHT_CYAN)
        self.display.info("Immutable OCO", "ENFORCED (All orders)", Colors.BRIGHT_GREEN)
        self.display.info("Min R:R Ratio", f"{self.min_rr_ratio}:1 (Charter Immutable)", Colors.BRIGHT_GREEN)
        self.display.info("Min Notional", f"${self.min_notional_usd:,} (Charter Immutable)", Colors.BRIGHT_GREEN)
        self.display.info("Max Daily Loss", f"{self.max_daily_loss}% (Charter Breaker)", Colors.BRIGHT_GREEN)
        self.display.info("Max Latency", f"{self.charter.MAX_PLACEMENT_LATENCY_MS}ms (Charter 2.1)", Colors.BRIGHT_GREEN)
        
        self.display.section("ENVIRONMENT CONFIGURATION")
        self.display.info("Environment", env_label, env_color)
        self.display.info("API Endpoint", self.oanda.api_base, Colors.BRIGHT_CYAN)
        self.display.info("Account ID", self.oanda.account_id, Colors.BRIGHT_CYAN)
        self.display.info("Market Data", "Real-time OANDA API", Colors.BRIGHT_GREEN)
        self.display.info("Order Execution", f"OANDA {env_label} API", env_color)
        
        self.display.section("SYSTEM COMPONENTS")
        self.display.info("Narration Logging", "ACTIVE → narration.jsonl", Colors.BRIGHT_GREEN)
        self.display.info("ML Intelligence", "ACTIVE" if ML_AVAILABLE else "DISABLED", 
                         Colors.BRIGHT_GREEN if ML_AVAILABLE else Colors.BRIGHT_BLACK)
        self.display.info("Hive Mind", "CONNECTED" if HIVE_AVAILABLE else "STANDALONE",
                         Colors.BRIGHT_GREEN if HIVE_AVAILABLE else Colors.BRIGHT_BLACK)
        self.display.info("Momentum System", "ACTIVE (rbotzilla_golden_age)" if MOMENTUM_SYSTEM_AVAILABLE else "DISABLED",
                         Colors.BRIGHT_GREEN if MOMENTUM_SYSTEM_AVAILABLE else Colors.BRIGHT_BLACK)
        hive_src = "CHARTER_MIN" if getattr(self, 'hive_trigger_enforced_by_charter', False) else "ENV_OVERRIDE"
        self.display.info("Hive Trigger Confidence", f"{self.hive_trigger_confidence:.2f} ({hive_src})", Colors.BRIGHT_CYAN)

        # Show preferred strategy families if advisor is available
        preferred_fams = getattr(self, 'strategy_advisor', None)
        if preferred_fams:
            fam_order = ", ".join(self.strategy_advisor.get_preferred_families())
            self.display.info("Strategy Families (preferred order)", fam_order, Colors.BRIGHT_CYAN)
        
        self.display.section("RISK PARAMETERS")
        self.display.info("Position Size", f"~{self.position_size:,} units (dynamic per pair)", Colors.BRIGHT_CYAN)
        self.display.info("Stop Loss", f"{self.stop_loss_pips} pips", Colors.BRIGHT_CYAN)
        self.display.info("Take Profit", f"{self.take_profit_pips} pips (3.2:1 R:R)", Colors.BRIGHT_CYAN)
        self.display.info("Max Positions", "3 concurrent", Colors.BRIGHT_CYAN)
        print()
        self.display.warning("⚠️  Charter requires $15k min notional - positions sized accordingly")
        
        self.display.section("OANDA CONNECTION")
        self.display.connection_status(f"OANDA {env_label} API", "READY")
        
        print()
        self.display.alert(f"✅ RBOTzilla Engine Ready - {env_label} Environment", "SUCCESS")
        
        self.display.divider()
        print()
    
    def _sync_positions_from_oanda(self):
        """
        Sync current_positions from OANDA API to ensure correlation gate has accurate data.
        This is critical to prevent stale position data from blocking valid trades.
        """
        try:
            api_base = self.oanda.api_base
            headers = self.oanda.headers
            account_id = self.oanda.account_id
            
            response = requests.get(
                f"{api_base}/v3/accounts/{account_id}/openPositions",
                headers=headers,
                timeout=10
            )
            
            if response.status_code != 200:
                self.display.warning(f"⚠️  Could not sync positions from OANDA: {response.status_code}")
                return
            
            data = response.json()
            positions = data.get('positions', [])
            
            # Clear stale positions and rebuild from OANDA
            self.current_positions = []
            
            for pos in positions:
                instrument = pos.get('instrument')
                
                # Check long side
                long_units = float(pos.get('long', {}).get('units', 0))
                if long_units != 0:
                    gate_position = Position(
                        symbol=instrument,
                        side="LONG",
                        units=abs(long_units),
                        entry_price=float(pos.get('long', {}).get('averagePrice', 0)),
                        current_price=float(pos.get('long', {}).get('averagePrice', 0)),
                        pnl=float(pos.get('long', {}).get('unrealizedPL', 0)),
                        pnl_pips=0.0,
                        margin_used=float(pos.get('marginUsed', 0)),
                        position_id=pos.get('long', {}).get('tradeIDs', ['unknown'])[0]
                    )
                    self.current_positions.append(gate_position)
                
                # Check short side
                short_units = float(pos.get('short', {}).get('units', 0))
                if short_units != 0:
                    gate_position = Position(
                        symbol=instrument,
                        side="SHORT",
                        units=abs(short_units),
                        entry_price=float(pos.get('short', {}).get('averagePrice', 0)),
                        current_price=float(pos.get('short', {}).get('averagePrice', 0)),
                        pnl=float(pos.get('short', {}).get('unrealizedPL', 0)),
                        pnl_pips=0.0,
                        margin_used=float(pos.get('marginUsed', 0)),
                        position_id=pos.get('short', {}).get('tradeIDs', ['unknown'])[0]
                    )
                    self.current_positions.append(gate_position)
            
            if self.current_positions:
                self.display.success(f"✅ Synced {len(self.current_positions)} positions from OANDA")
                for p in self.current_positions:
                    self.display.info(f"   {p.symbol}", f"{p.side} {p.units:,.0f} units", Colors.BRIGHT_CYAN)
            else:
                self.display.info("ℹ️  No open positions in OANDA account", "", Colors.BRIGHT_CYAN)
                
        except Exception as e:
            self.display.warning(f"⚠️  Position sync error: {e}")
    
    def get_current_price(self, pair):
        """Get current real-time price from OANDA API (environment-agnostic)"""
        try:
            # Get real-time prices from OANDA API (practice or live based on connector config)
            api_base = self.oanda.api_base
            headers = self.oanda.headers
            account_id = self.oanda.account_id
            
            response = requests.get(
                f"{api_base}/v3/accounts/{account_id}/pricing",
                headers=headers,
                params={"instruments": pair},
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                if 'prices' in data and len(data['prices']) > 0:
                    price_info = data['prices'][0]
                    bid = float(price_info['bids'][0]['price'])
                    ask = float(price_info['asks'][0]['price'])
                    spread = round((ask - bid) * 10000, 1)  # in pips
                    
                    return {
                        'bid': bid,
                        'ask': ask,
                        'spread': spread,
                        'real_api': True  # Real API data, not simulated
                    }
            
            # If API call failed, log warning and use fallback
            self.display.warning(f"⚠️  API pricing failed for {pair} (status {response.status_code}), using fallback")
            return self._get_fallback_price(pair)
            
        except Exception as e:
            self.display.warning(f"⚠️  API error for {pair}: {str(e)}, using fallback")
            return self._get_fallback_price(pair)
    
    def _get_fallback_price(self, symbol: str) -> Dict:
        """Fallback to approximate prices if live API unavailable"""
        import random
        
        # Approximate market prices for ALL pairs (updated Oct 2025)
        base_prices = {
            # Major USD pairs
            'EUR_USD': 1.0800,
            'GBP_USD': 1.2700,
            'USD_JPY': 150.00,
            'USD_CHF': 0.8800,
            'AUD_USD': 0.6500,
            'USD_CAD': 1.3600,
            'NZD_USD': 0.6000,
            
            # Major crosses (no USD)
            'EUR_GBP': 0.8500,
            'EUR_JPY': 162.00,
            'GBP_JPY': 190.00,
            'AUD_JPY': 97.50,
            'CHF_JPY': 170.00,
            
            # European crosses
            'EUR_CHF': 0.9500,
            'GBP_CHF': 1.1200,
            
            # Commodity currency crosses
            'AUD_CHF': 0.5700,
            'NZD_CHF': 0.5300,
            'EUR_AUD': 1.6600,
            'GBP_AUD': 1.9500
        }
        
        if symbol not in base_prices:
            self.display.error(f"Symbol {symbol} not configured - add to base_prices dict")
            return None
        
        # Add small random variation (simulate live market)
        base = base_prices[symbol]
        variation = random.uniform(-0.001, 0.001)
        mid_price = base + variation
        
        # Calculate spread
        pip_size = 0.0001 if 'JPY' not in symbol else 0.01
        spread = 2 * pip_size  # 2 pip spread
        
        return {
            'symbol': symbol,
            'bid': round(mid_price - spread/2, 5),
            'ask': round(mid_price + spread/2, 5),
            'spread': spread,
            'fallback': True
        }
    
    def evaluate_signal_with_ml(self, symbol: str, signal_data: Dict, candles: list = None) -> Tuple[bool, Dict]:
        """
        Filter signals through ML regime detection
        
        Args:
            symbol: Trading pair
            signal_data: Signal dict with 'action', 'entry', etc.
            candles: Historical candles for regime detection
        
        Returns:
            (bool, dict): (approved, analysis_details)
        """
        if not self.regime_detector:
            # No ML, accept signal
            return True, {'ml_available': False, 'reason': 'ML not available'}
        
        try:
            # Get prices for regime analysis
            if candles:
                # Extract close prices from candles
                prices = []
                for c in candles:
                    if isinstance(c, dict):
                        if 'mid' in c and 'c' in c['mid']:
                            prices.append(float(c['mid']['c']))
                        elif 'close' in c:
                            prices.append(float(c['close']))
                if len(prices) < 20:
                    return True, {'ml_available': True, 'reason': 'Insufficient price data', 'approved': True}
            else:
                return True, {'ml_available': True, 'reason': 'No candle data for regime', 'approved': True}
            
            # Detect market regime using StochasticRegimeDetector
            regime_data = self.regime_detector.detect_regime(prices)
            regime = regime_data.regime.value if hasattr(regime_data, 'regime') else str(regime_data)
            confidence = regime_data.confidence if hasattr(regime_data, 'confidence') else 0.5
            
            # Accept signals based on regime
            direction = signal_data.get('action', 'buy').lower()
            
            if regime == 'bull' and direction == 'buy':
                # Bull regime + buy signal = strong alignment
                log_narration(
                    event_type="ML_SIGNAL_APPROVED",
                    details={"symbol": symbol, "regime": regime, "confidence": confidence, "reason": "Bull regime + BUY"},
                    symbol=symbol,
                    venue="ml_intelligence"
                )
                return True, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': True}
            
            elif regime == 'bear' and direction == 'sell':
                # Bear regime + sell signal = strong alignment
                log_narration(
                    event_type="ML_SIGNAL_APPROVED",
                    details={"symbol": symbol, "regime": regime, "confidence": confidence, "reason": "Bear regime + SELL"},
                    symbol=symbol,
                    venue="ml_intelligence"
                )
                return True, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': True}
            
            elif regime == 'sideways' and confidence > 0.7:
                # Sideways with high confidence - be more selective
                if confidence >= 0.8:
                    log_narration(
                        event_type="ML_SIGNAL_APPROVED",
                        details={"symbol": symbol, "regime": regime, "confidence": confidence, "reason": "High confidence in sideways market"},
                        symbol=symbol,
                        venue="ml_intelligence"
                    )
                    return True, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': True}
                else:
                    return False, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': False, 'reason': f'Low confidence in sideways market ({confidence:.2f})'}
            
            elif regime == 'crash':
                # Crash regime - only accept sells with high confidence
                if direction == 'sell' and confidence > 0.6:
                    return True, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': True}
                return False, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': False, 'reason': 'Crash regime - risk management'}
            
            # Default: accept with caution
            return True, {'ml_available': True, 'regime': regime, 'confidence': confidence, 'approved': True, 'reason': 'Default accept'}
        
        except Exception as e:
            # ML error - be permissive, don't block trade
            self.display.warning(f"ML evaluation error for {symbol}: {str(e)}")
            return True, {'ml_available': True, 'error': str(e), 'approved': True}
    
    def amplify_signal_with_hive(self, symbol: str, signal_data: Dict) -> Dict:
        """
        Amplify signal strength through Hive Mind consensus
        
        Args:
            symbol: Currency pair
            signal_data: Signal dict with 'action', 'entry', etc.
        
        Returns:
            Amplified signal dict with hive_amplified flag and confidence
        """
        if not self.hive_mind:
            # No Hive, return original
            return signal_data
        
        try:
            # Query Hive Mind for consensus on this symbol
            market_data = {
                "symbol": symbol.replace('_', ''),
                "action": signal_data.get('action', 'buy'),
                "entry_price": signal_data.get('entry', 0),
                "timeframe": "M15"
            }
            
            hive_analysis = self.hive_mind.delegate_analysis(market_data)
            
            if not hive_analysis:
                return signal_data
            
            consensus = hive_analysis.consensus_signal
            confidence = hive_analysis.consensus_confidence
            
            # Check if Hive strongly agrees with signal
            if confidence >= self.hive_trigger_confidence:
                # Hive consensus is strong
                
                # Amplify the signal
                amplified_signal = signal_data.copy()
                amplified_signal['hive_amplified'] = True
                amplified_signal['hive_confidence'] = confidence
                amplified_signal['hive_consensus'] = consensus.value if hasattr(consensus, 'value') else str(consensus)
                
                log_narration(
                    event_type="HIVE_CONSENSUS_STRONG",
                    details={
                        "symbol": symbol,
                        "consensus": consensus.value if hasattr(consensus, 'value') else str(consensus),
                        "confidence": confidence,
                        "original_signal": signal_data.get('tag', 'unknown'),
                        "amplified": True
                    },
                    symbol=symbol,
                    venue="hive_mind"
                )
                
                self.display.success(f"🐝 Hive amplified {symbol}: {consensus} ({confidence:.2f})")
                
                return amplified_signal
            else:
                # Hive consensus weak - return original signal
                log_narration(
                    event_type="HIVE_CONSENSUS_WEAK",
                    details={
                        "symbol": symbol,
                        "consensus": consensus.value if hasattr(consensus, 'value') else str(consensus),
                        "confidence": confidence,
                        "threshold": self.hive_trigger_confidence
                    },
                    symbol=symbol,
                    venue="hive_mind"
                )
                
                return signal_data
        
        except Exception as e:
            # Hive error - return original signal
            self.display.warning(f"Hive amplification error for {symbol}: {str(e)}")
            return signal_data
    
    def calculate_position_size(self, symbol: str, entry_price: float, regime: str = 'triage') -> int:
        """
        Calculate position size using Aggressive Money Machine logic:
        1. Kelly Criterion for optimal fraction
        2. Wolf Pack regime multipliers
        3. Volatility adjustment
        4. Charter compliance validation
        """
        import math
        
        pip_size = 0.01 if 'JPY' in symbol else 0.0001
        
        # ========================================================================
        # AGGRESSIVE MONEY MACHINE: Dynamic Kelly-based sizing
        # ========================================================================
        if self.dynamic_sizer and self.aggressive_scaling_enabled:
            try:
                # Get account balance for percentage-based sizing
                account_balance = 5000.0  # Default
                try:
                    if hasattr(self.oanda, 'get_account_info'):
                        acc = self.oanda.get_account_info()
                        account_balance = float(acc.get('NAV', acc.get('balance', 5000.0)))
                except Exception:
                    pass
                
                # Update dynamic sizer with current balance
                self.dynamic_sizer.update_account_balance(account_balance)
                
                # Calculate Kelly-optimal position size
                kelly_result = self.dynamic_sizer.calculate_position_size(
                    symbol=symbol,
                    entry_price=entry_price,
                    stop_loss_pips=self.stop_loss_pips
                )
                
                if kelly_result and kelly_result.recommended_units > 0:
                    base_units = kelly_result.recommended_units
                    
                    # Apply Wolf Pack regime multiplier
                    wolf_multiplier = 1.0
                    if regime in self.wolf_pack_settings:
                        wolf_multiplier = self.wolf_pack_settings[regime].get('position_multiplier', 1.0)
                    
                    # Calculate final position with regime adjustment
                    position_size = int(base_units * wolf_multiplier)
                    
                    # Log the aggressive sizing decision
                    log_narration(
                        event_type="AGGRESSIVE_SIZING",
                        details={
                            "symbol": symbol,
                            "regime": regime,
                            "kelly_units": base_units,
                            "wolf_multiplier": wolf_multiplier,
                            "final_units": position_size,
                            "account_balance": account_balance,
                            "confidence": kelly_result.confidence
                        },
                        symbol=symbol,
                        venue="oanda"
                    )
                    
                    # Ensure minimum notional is still met
                    notional = position_size * entry_price
                    if notional >= self.min_notional_usd:
                        return position_size
                    
            except Exception as e:
                self.display.warning(f"⚠️  Kelly sizing failed: {e}, using fallback")
        
        # ========================================================================
        # FALLBACK: Basic Charter-compliant sizing
        # ========================================================================
        required_units = math.ceil(self.min_notional_usd / entry_price)
        
        # JPY pairs need special handling
        if 'JPY' in symbol:
            required_units = math.ceil(required_units * 10)
        
        # Round up to nearest 100 for clean sizing
        position_size = math.ceil(required_units / 100) * 100
        
        # Verify we meet minimum notional
        notional = position_size * entry_price
        if notional < self.min_notional_usd:
            add_units = 100 if 'JPY' not in symbol else 1000
            position_size += add_units
        
        return position_size
    
    def calculate_stop_take_levels(self, symbol: str, direction: str, entry_price: float):
        """Calculate stop loss and take profit levels (Charter-compliant, symbol-aware precision)."""
        # Pip size
        pip_size = 0.01 if 'JPY' in symbol else 0.0001
        # Price precision: JPY pairs usually 3 decimals, others 5
        decimals = 3 if 'JPY' in symbol else 5

        if direction == "BUY":
            stop_loss = entry_price - (self.stop_loss_pips * pip_size)
            take_profit = entry_price + (self.take_profit_pips * pip_size)
        else:  # SELL
            stop_loss = entry_price + (self.stop_loss_pips * pip_size)
            take_profit = entry_price - (self.take_profit_pips * pip_size)

        return round(stop_loss, decimals), round(take_profit, decimals)
    
    def _evaluate_hedge_conditions(self, symbol: str, direction: str, units: float, 
                                   entry_price: float, notional: float, current_margin_used: float) -> Dict:
        """
        Intelligent multi-condition hedge evaluation
        Analyzes portfolio state, market conditions, and risk exposure
        
        Returns:
            Dict with 'execute' (bool) and 'reason' (str)
        """
        # Get account NAV for calculations
        account_nav = 2000.0
        try:
            if hasattr(self.oanda, 'get_account_info'):
                account_info = self.oanda.get_account_info()
                account_nav = float(account_info.get('NAV', 2000.0))
        except Exception:
            pass
        
        # Calculate current margin utilization
        margin_utilization = (current_margin_used / account_nav) if account_nav > 0 else 0
        
        # Evaluate hedge opportunity
        hedge_opp = self.hedge_engine.evaluate_hedge_opportunity(symbol)
        
        # ========================================================================
        # HEDGE DECISION RULES - Multi-Condition Analysis
        # ========================================================================
        
        # RULE 1: No suitable hedge pair available
        if not hedge_opp['hedge_available']:
            return {'execute': False, 'reason': 'No inverse correlation pair found'}
        
        # RULE 2: Weak correlation (< -0.50 threshold)
        if abs(hedge_opp['correlation']) < 0.50:
            return {'execute': False, 'reason': f"Weak correlation ({hedge_opp['correlation']:.2f})"}
        
        # RULE 3: High margin usage (>25%) - ALWAYS hedge to protect capital
        if margin_utilization > 0.25:
            return {
                'execute': True, 
                'reason': f'High margin usage ({margin_utilization:.1%}) - protective hedge required'
            }
        
        # RULE 4: Large notional (>$20k) - Hedge to reduce single-position risk
        if notional > 20000:
            return {
                'execute': True,
                'reason': f'Large notional (${notional:,.0f}) - risk reduction hedge'
            }
        
        # RULE 5: Multiple positions in same currency - Hedge cumulative exposure
        usd_exposure_count = sum(1 for pos in self.current_positions 
                                 if 'USD' in pos.symbol and pos.side == ("LONG" if direction == "BUY" else "SHORT"))
        if usd_exposure_count >= 2:
            return {
                'execute': True,
                'reason': f'Cumulative USD exposure ({usd_exposure_count + 1} positions) - correlation hedge'
            }
        
        # RULE 6: Strong inverse correlation (< -0.70) - Opportunistic hedge
        if hedge_opp['correlation'] < -0.70:
            return {
                'execute': True,
                'reason': f"Strong inverse correlation ({hedge_opp['correlation']:.2f}) - optimal hedge opportunity"
            }
        
        # RULE 7: Moderate margin (15-25%) + Strong correlation - Selective hedge
        if 0.15 < margin_utilization <= 0.25 and hedge_opp['correlation'] < -0.65:
            return {
                'execute': True,
                'reason': f'Moderate margin ({margin_utilization:.1%}) + strong correlation - proactive hedge'
            }
        
        # DEFAULT: Skip hedge for low-risk scenarios
        return {
            'execute': False,
            'reason': f'Low risk profile (margin: {margin_utilization:.1%}, notional: ${notional:,.0f})'
        }
    
    def place_trade(self, symbol: str, direction: str, strategy_meta: Optional[Dict] = None):
        """Place Charter-compliant OCO order with full logging (environment-agnostic)"""
        try:
            # Get current price
            price_data = self.get_current_price(symbol)
            if not price_data:
                self.display.error(f"Could not get price for {symbol}")
                log_narration(
                    event_type="PRICE_ERROR",
                    details={"symbol": symbol, "error": "No price data"},
                    symbol=symbol,
                    venue="oanda"
                )
                return None
            
            # Use bid for SELL, ask for BUY
            entry_price = price_data['ask'] if direction == "BUY" else price_data['bid']
            
            # Calculate Charter-compliant position size
            position_size = self.calculate_position_size(symbol, entry_price)
            
            # Calculate notional value in TRUE USD (handles cross pairs correctly)
            notional_value = get_usd_notional(position_size, symbol, entry_price, self.oanda)
            if notional_value is None:
                self.display.error(f"❌ Cannot calculate USD notional for {symbol}")
                return None
            
            # ========================================================================
            # 🛡️ PRE-TRADE GUARDIAN GATE CHECK (NEW)
            # ========================================================================
            # Get current account margin
            current_margin_used = 0
            try:
                if hasattr(self.oanda, 'get_account_info'):
                    account_info = self.oanda.get_account_info()
                    current_margin_used = float(account_info.get('marginUsed', 0))
            except Exception as e:
                self.display.warn(f"⚠️  Could not fetch margin info: {e}")
            
            # Create order object for gate validation
            gate_order = Order(
                symbol=symbol,
                side=direction,
                units=position_size,
                price=entry_price,
                order_id=f"pending_{symbol}_{int(time.time())}"
            )
            
            # Run pre-trade gate
            gate_result = self.gate.pre_trade_gate(
                new_order=gate_order,
                current_positions=self.current_positions,
                pending_orders=self.pending_orders,
                total_margin_used=current_margin_used
            )
            
            # If gate rejects order, stop here
            if not gate_result.allowed:
                self.display.error(f"❌ GUARDIAN GATE BLOCKED: {gate_result.reason}")
                if gate_result.action == "AUTO_CANCEL":
                    self.display.alert(f"   Action: {gate_result.action}", "WARNING")
                log_narration(
                    event_type="GATE_REJECTION",
                    details={
                        "symbol": symbol,
                        "reason": gate_result.reason,
                        "action": gate_result.action,
                        "margin_used": current_margin_used
                    },
                    symbol=symbol,
                    venue="oanda"
                )
                return None
            
            # CHARTER ENFORCEMENT: Verify minimum notional (GATED PRE-ORDER VALIDATION)
            if notional_value < self.min_notional_usd:
                self.display.error(f"❌ CHARTER VIOLATION: Notional ${notional_value:,.0f} < ${self.min_notional_usd:,}")
                self.display.error(f"   GATED LOGIC: Order blocked before submission")
                log_narration(
                    event_type="CHARTER_VIOLATION",
                    details={
                        "action": "PRE_ORDER_BLOCK",
                        "violation": "MIN_NOTIONAL_PRE_ORDER",
                        "notional_usd": round(notional_value, 2),
                        "min_required_usd": self.min_notional_usd,
                        "symbol": symbol,
                        "direction": direction,
                        "position_size": position_size,
                        "entry_price": entry_price,
                        "enforcement": "GATED_LOGIC_AUTOMATIC",
                        "status": "BLOCKED_BEFORE_SUBMISSION"
                    },
                    symbol=symbol,
                    venue="oanda"
                )
                return None
            
            # Display market data
            self.display.section("MARKET SCAN")
            
            # Show if using real API or fallback data
            if price_data.get('real_api'):
                self.display.success("✅ Real-time OANDA API data")
            else:
                self.display.warning("⚠️  Fallback simulated prices (API unavailable)")
            
            self.display.market_data(
                symbol,
                price_data['bid'],
                price_data['ask'],
                price_data['spread'] / 0.0001  # Convert to pips
            )
            
            # Calculate stops
            stop_loss, take_profit = self.calculate_stop_take_levels(symbol, direction, entry_price)
            
            # CHARTER ENFORCEMENT: Verify R:R ratio
            risk = abs(entry_price - stop_loss)
            reward = abs(take_profit - entry_price)
            rr_ratio = reward / risk if risk > 0 else 0
            
            # Use small tolerance for floating point comparison
            if rr_ratio < (self.min_rr_ratio - 0.01):
                self.display.error(f"❌ CHARTER VIOLATION: R:R {rr_ratio:.2f} < {self.min_rr_ratio}")
                log_narration(
                    event_type="CHARTER_VIOLATION",
                    details={
                        "violation": "MIN_RR_RATIO",
                        "rr_ratio": rr_ratio,
                        "min_required": self.min_rr_ratio,
                        "symbol": symbol
                    },
                    symbol=symbol,
                    venue="oanda"
                )
                return None
            
            # Determine units (negative for SELL)
            units = position_size if direction == "BUY" else -position_size
            
            # Display Charter compliance
            self.display.info("Position Size", f"{abs(units):,} units (dynamic)", Colors.BRIGHT_CYAN)
            self.display.info("Notional Value", f"${notional_value:,.0f} ✅", Colors.BRIGHT_GREEN)
            self.display.info("R:R Ratio", f"{rr_ratio:.2f}:1 ✅", Colors.BRIGHT_GREEN)
            
            # Place OCO order
            self.display.alert(f"Placing Charter-compliant {direction} OCO order for {symbol}...", "INFO")
            
            # Log pre-trade
            log_narration(
                event_type="TRADE_SIGNAL",
                details={
                    "symbol": symbol,
                    "direction": direction,
                    "entry": entry_price,
                    "stop_loss": stop_loss,
                    "take_profit": take_profit,
                    "units": units,
                    "notional": notional_value,
                    "rr_ratio": rr_ratio,
                    "live_data": not price_data.get('fallback', False)
                },
                symbol=symbol,
                venue="oanda"
            )
            
            # Execute order via OANDA API (environment determined by connector config)
            order_result = self.oanda.place_oco_order(
                instrument=symbol,
                entry_price=entry_price,
                stop_loss=stop_loss,
                take_profit=take_profit,
                units=units,
                ttl_hours=6.0  # Charter: 6 hour max hold
            )
            
            if order_result.get('success'):
                order_id = order_result.get('order_id')
                latency_ms = order_result.get('latency_ms', 0)
                
                # CHARTER ENFORCEMENT: Verify latency
                if latency_ms > self.charter.MAX_PLACEMENT_LATENCY_MS:
                    self.display.error(f"❌ CHARTER VIOLATION: Latency {latency_ms:.1f}ms > 300ms")
                    log_narration(
                        event_type="CHARTER_VIOLATION",
                        details={
                            "violation": "MAX_LATENCY",
                            "latency_ms": latency_ms,
                            "max_allowed": self.charter.MAX_PLACEMENT_LATENCY_MS,
                            "order_id": order_id
                        },
                        symbol=symbol,
                        venue="oanda"
                    )
                    # Continue anyway since order was placed (just log violation)
                
                # Display successful trade
                self.display.trade_open(
                    symbol,
                    direction,
                    entry_price,
                    f"Stop: {stop_loss:.5f} | Target: {take_profit:.5f} | Size: {abs(units):,} units | Notional: ${notional_value:,.0f}"
                )
                
                # Strategy meta may be passed in from the signal layer (family, name)
                strategy_family = None
                strategy_name = None
                if isinstance(strategy_meta, dict):
                    strategy_family = strategy_meta.get('family')
                    strategy_name = strategy_meta.get('strategy_name') or strategy_meta.get('name')

                self.active_positions[order_id] = {
                    'symbol': symbol,
                    'direction': direction,
                    'entry': entry_price,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'units': units,
                    'notional': notional_value,
                    'rr_ratio': rr_ratio,
                    'timestamp': datetime.now(timezone.utc),
                    # Strategy meta
                    'strategy_family': strategy_family,
                    'strategy_name': strategy_name,
                    # Two-step surgeon SL stage:
                    # 0 = fresh OCO with hard SL
                    # 1 = SL moved to BE+lock, TP still active
                    # 2 = TP cancelled, trailing SL active
                    'two_step_stage': 0,
                }
                
                # ========================================================================
                # 🛡️ TRACK POSITION FOR GUARDIAN GATE ONGOING MONITORING
                # ========================================================================
                gate_position = Position(
                    symbol=symbol,
                    side="LONG" if direction == "BUY" else "SHORT",
                    units=abs(units),
                    entry_price=entry_price,
                    current_price=entry_price,
                    pnl=0.0,
                    pnl_pips=0.0,
                    margin_used=(notional_value * 0.02),  # Typical FOREX margin ~2%
                    position_id=order_id
                )
                self.current_positions.append(gate_position)
                self.display.info("🛡️ Position tracked for guardian gate monitoring", "", Colors.BRIGHT_CYAN)
                
                self.total_trades += 1
                
                # Log successful placement with narration
                log_narration(
                    event_type="TRADE_OPENED",
                    details={
                        "symbol": symbol,
                        "direction": direction,
                        "entry_price": entry_price,
                        "stop_loss": stop_loss,
                        "take_profit": take_profit,
                        "size": abs(units),
                        "notional": notional_value,
                        "rr_ratio": rr_ratio,
                        "order_id": order_id,
                        "charter_compliant": True
                    },
                    symbol=symbol,
                    venue="oanda"
                )
                
                # Get Rick's commentary
                rick_comment = self.narrator.generate_commentary(
                    event_type="TRADE_OPENED",
                    details={
                        "symbol": symbol,
                        "direction": direction,
                        "entry": entry_price,
                        "stop_loss": stop_loss,
                        "take_profit": take_profit,
                        "rr_ratio": rr_ratio,
                        "notional": notional_value,
                        "reasoning": f"Charter-compliant {rr_ratio:.2f}:1 R:R, ${notional_value:,.0f} notional"
                    }
                )
                
                self.display.alert(f"✅ OCO order placed! Order ID: {order_id}", "SUCCESS")
                self.display.info("Latency", f"{latency_ms:.1f}ms", Colors.BRIGHT_CYAN)
                self.display.rick_says(rick_comment)
                
                # ========================================================================
                # 🛡️ QUANTITATIVE HEDGE ENGINE - INTELLIGENT MULTI-CONDITION ANALYSIS
                # ========================================================================
                if self.hedge_engine:
                    hedge_decision = self._evaluate_hedge_conditions(
                        symbol=symbol,
                        direction=direction,
                        units=abs(units),
                        entry_price=entry_price,
                        notional=notional_value,
                        current_margin_used=current_margin_used
                    )
                    
                    if hedge_decision['execute']:
                        self.display.section("HEDGE ANALYSIS")
                        self.display.info("Hedge Decision", hedge_decision['reason'], Colors.BRIGHT_YELLOW)
                        
                        hedge_position = self.hedge_engine.execute_hedge(
                            primary_symbol=symbol,
                            primary_side=direction,
                            position_size=abs(units),
                            entry_price=entry_price
                        )
                        
                        if hedge_position:
                            # Store hedge reference
                            self.active_hedges[order_id] = hedge_position
                            
                            self.display.success(
                                f"🛡️ HEDGE EXECUTED: {hedge_position.side} {hedge_position.size:.0f} units "
                                f"{hedge_position.symbol} @ {hedge_position.hedge_ratio:.0%} coverage"
                            )
                            self.display.info(
                                "Correlation", 
                                f"{hedge_position.correlation:.2f} (inverse)", 
                                Colors.BRIGHT_CYAN
                            )
                            
                            log_narration(
                                event_type="HEDGE_EXECUTED",
                                details={
                                    "primary_symbol": symbol,
                                    "hedge_symbol": hedge_position.symbol,
                                    "hedge_side": hedge_position.side,
                                    "hedge_size": hedge_position.size,
                                    "hedge_ratio": hedge_position.hedge_ratio,
                                    "correlation": hedge_position.correlation,
                                    "reason": hedge_decision['reason']
                                },
                                symbol=symbol,
                                venue="quant_hedge"
                            )
                            
                            # TODO: Place actual hedge order via OANDA API if live trading
                            # hedge_order_id = self.oanda.place_oco_order(
                            #     instrument=hedge_position.symbol,
                            #     entry_price=hedge_position.entry_price,
                            #     units=hedge_position.size if hedge_position.side == 'BUY' else -hedge_position.size,
                            #     ...
                            # )
                        else:
                            self.display.warning("⚠️  No suitable hedge pair found")
                    else:
                        self.display.info("Hedge Decision", f"SKIPPED - {hedge_decision['reason']}", Colors.DIM)
                
                return order_id
            else:
                error = order_result.get('error', 'Unknown error')
                self.display.error(f"Order failed: {error}")
                
                log_narration(
                    event_type="ORDER_FAILED",
                    details={
                        "symbol": symbol,
                        "direction": direction,
                        "error": error,
                        "environment": self.environment
                    },
                    symbol=symbol,
                    venue="oanda"
                )
                
                return None
                
        except Exception as e:
            self.display.error(f"Error placing trade: {e}")
            log_narration(
                event_type="TRADE_ERROR",
                details={"error": str(e), "symbol": symbol},
                symbol=symbol,
                venue="oanda"
            )
            return None
    
    def check_positions(self):
        """Check status of open positions via OANDA API and sync gate position tracking"""
        # Sync positions from OANDA to ensure correlation gate has accurate data
        self._sync_positions_from_oanda()
        return

    async def trade_manager_loop(self):
        """Background loop that evaluates active positions and runs two-step surgeon SL logic.

        Behavior:
        - STEP 1: When a position reaches step1_rr_trigger (e.g. 1R), move SL to BE+small lock,
                  KEEP TP in place. This is the "surgeon" upgrade from pure risk to locked risk.
        - STEP 2: When either:
             * RR >= step2_rr_trigger (e.g. 2R), or
             * Hive consensus is strong in the trade direction, or
             * MomentumDetector confirms strong momentum,
          then:
             * cancel the TP leg of the OCO, and
             * set an adaptive trailing SL using SmartTrailingSystem.
        - All changes are logged with log_narration for full auditability.
        """
        while self.is_running:
            try:
                # Periodically refresh account info and update risk manager
                try:
                    if hasattr(self.oanda, 'get_account_info') and self.risk_manager:
                        acc_info = self.oanda.get_account_info()
                        bal = acc_info.get('balance') if isinstance(acc_info, dict) else None
                        if bal is not None:
                            try:
                                self.risk_manager.update_equity(float(bal))
                            except Exception:
                                pass
                except Exception:
                    pass

                now = datetime.now(timezone.utc)
                for order_id, pos in list(self.active_positions.items()):
                    # If we already converted to trailing and TP is gone, we can skip
                    # further TP work here. (Trailing itself is handled by the initial jump.)
                    if pos.get('tp_cancelled'):
                        continue

                    # Age check
                    age = (now - pos['timestamp']).total_seconds()
                    if age < self.min_position_age_seconds:
                        continue

                    symbol = pos['symbol']
                    direction = pos['direction']
                    entry_price = pos['entry']

                    # Get current price to calculate profit
                    try:
                        current_price_data = self.get_current_price(symbol)
                        if not current_price_data:
                            continue
                        current_price = (
                            current_price_data['ask'] if direction == 'BUY'
                            else current_price_data['bid']
                        )
                    except Exception as e:
                        self.display.warning(f"Could not fetch current price for {symbol}: {e}")
                        continue

                    # Calculate profit in pips and ATR multiples
                    pip_size = 0.0001 if 'JPY' not in symbol else 0.01
                    if direction == 'BUY':
                        profit_pips = (current_price - entry_price) / pip_size
                    else:
                        profit_pips = (entry_price - current_price) / pip_size

                    # Estimate ATR (use stop_loss_pips / 1.2 as proxy, since stop = 1.2 * ATR)
                    estimated_atr_pips = self.stop_loss_pips / 1.2
                    profit_atr_multiple = (
                        profit_pips / estimated_atr_pips if estimated_atr_pips > 0 else 0
                    )

                    # Two-step surgeon SL tracking
                    stage = pos.get('two_step_stage', 0)
                    pos['two_step_stage'] = stage  # normalize
                    risk_pips = float(self.stop_loss_pips) if self.stop_loss_pips > 0 else 1.0
                    rr_achieved = profit_pips / risk_pips

                    # ──────────────────────────────────────────────────────────────
                    # STEP 1: move SL to BE + small lock once trade reaches 1R
                    # ──────────────────────────────────────────────────────────────
                    if (
                        stage == 0
                        and rr_achieved >= self.step1_rr_trigger
                        and profit_pips > 0
                    ):
                        try:
                            lock_pips = self.step1_lock_in_pips
                            if direction == 'BUY':
                                # SL below current price, above entry to lock profit
                                new_sl = entry_price + lock_pips * pip_size
                                max_allowed = current_price - (1.0 * pip_size)
                                new_sl = min(new_sl, max_allowed)
                            else:
                                # For shorts, SL must be above current price, below entry to lock profit
                                new_sl = entry_price - lock_pips * pip_size
                                min_allowed = current_price + (1.0 * pip_size)
                                new_sl = max(new_sl, min_allowed)

                            # Symbol-appropriate rounding
                            decimals = 3 if 'JPY' in symbol else 5
                            new_sl = round(new_sl, decimals)

                            trades = self.oanda.get_trades()
                            for t in trades:
                                trade_instrument = t.get('instrument') or t.get('symbol')
                                trade_id = (
                                    t.get('id')
                                    or t.get('tradeID')
                                    or t.get('trade_id')
                                )
                                if not trade_id:
                                    continue
                                if trade_instrument and trade_instrument.replace('.', '_').upper() == symbol:
                                    set_resp = self.oanda.set_trade_stop(trade_id, new_sl)

                                    log_narration(
                                        event_type="STEP1_SL_BE_LOCK",
                                        details={
                                            "order_id": order_id,
                                            "trade_id": trade_id,
                                            "symbol": symbol,
                                            "direction": direction,
                                            "entry_price": entry_price,
                                            "new_sl": new_sl,
                                            "profit_pips": profit_pips,
                                            "rr_achieved": rr_achieved,
                                            "response": set_resp,
                                        },
                                        symbol=symbol,
                                        venue="oanda",
                                    )

                                    pos['two_step_stage'] = 1
                                    pos['step1_sl'] = new_sl
                                    self.display.success(
                                        f"🔪 STEP 1: {symbol} SL moved to BE+{lock_pips:.1f} pips (trade {trade_id})"
                                    )
                                    break

                            # Do not attempt STEP 2 in the same loop iteration
                            continue

                        except Exception as e:
                            self.display.error(f"Error in STEP 1 SL adjustment for {symbol}: {e}")
                            log_narration(
                                event_type="STEP1_SL_ERROR",
                                details={"order_id": order_id, "error": str(e)},
                                symbol=symbol,
                                venue="oanda",
                            )
                            # Fall through to next trade
                            continue

                    # ──────────────────────────────────────────────────────────────
                    # Hive & Momentum signals (for STEP 2 gating)
                    # ──────────────────────────────────────────────────────────────
                    hive_signal_confirmed = False
                    momentum_signal_confirmed = False

                    # Query Hive Mind for consensus on this instrument
                    if self.hive_mind:
                        try:
                            market_data = {
                                "symbol": symbol.replace('_', ''),
                                "current_price": current_price,
                                "timeframe": "M15",
                            }

                            analysis = self.hive_mind.delegate_analysis(market_data)
                            consensus = analysis.consensus_signal
                            confidence = analysis.consensus_confidence

                            # Log the analysis
                            log_narration(
                                event_type="HIVE_ANALYSIS",
                                details={
                                    "symbol": symbol,
                                    "consensus": (
                                        consensus.value
                                        if hasattr(consensus, 'value')
                                        else str(consensus)
                                    ),
                                    "confidence": confidence,
                                    "order_id": order_id,
                                    "profit_atr": profit_atr_multiple,
                                },
                                symbol=symbol,
                                venue="hive",
                            )

                            # Check hive consensus threshold
                            if (
                                confidence >= self.hive_trigger_confidence
                                and consensus in (SignalStrength.STRONG_BUY, SignalStrength.STRONG_SELL)
                            ):
                                if (
                                    direction == 'BUY'
                                    and consensus == SignalStrength.STRONG_BUY
                                ) or (
                                    direction == 'SELL'
                                    and consensus == SignalStrength.STRONG_SELL
                                ):
                                    hive_signal_confirmed = True
                                    self.display.info(
                                        f"Hive signal: {consensus.value} ({confidence:.2f}) for {symbol}",
                                        Colors.BRIGHT_CYAN,
                                    )
                        except Exception as e:
                            self.display.warning(f"Hive analysis error for {symbol}: {e}")

                    # Use MomentumDetector from rbotzilla_golden_age.py
                    if self.momentum_detector and profit_atr_multiple > 0:
                        try:
                            # Simple assumptions; in full system you'd plug real regime data
                            trend_strength = 0.7
                            market_cycle = 'BULL_MODERATE'
                            volatility = 1.0

                            has_momentum, momentum_strength = self.momentum_detector.detect_momentum(
                                profit_atr_multiple=profit_atr_multiple,
                                trend_strength=trend_strength,
                                cycle=market_cycle,
                                volatility=volatility,
                            )

                            if has_momentum:
                                momentum_signal_confirmed = True
                                self.display.info(
                                    f"Momentum detected: {momentum_strength:.2f}x strength for "
                                    f"{symbol} (profit: {profit_atr_multiple:.2f}x ATR)",
                                    Colors.BRIGHT_GREEN,
                                )

                                log_narration(
                                    event_type="MOMENTUM_DETECTED",
                                    details={
                                        "symbol": symbol,
                                        "profit_atr": profit_atr_multiple,
                                        "momentum_strength": momentum_strength,
                                        "order_id": order_id,
                                    },
                                    symbol=symbol,
                                    venue="momentum_detector",
                                )
                        except Exception as e:
                            self.display.warning(f"Momentum detection error for {symbol}: {e}")

                    # ──────────────────────────────────────────────────────────────
                    # STEP 2: cancel TP & convert to trailing SL
                    # ──────────────────────────────────────────────────────────────
                    should_convert_to_trailing = False
                    trigger_source = []

                    # Condition 1: pure R-multiple (e.g. >= 2R)
                    if rr_achieved >= self.step2_rr_trigger:
                        should_convert_to_trailing = True
                        trigger_source.append("RR")

                    # Condition 2: strong Hive alignment
                    if hive_signal_confirmed:
                        should_convert_to_trailing = True
                        trigger_source.append("Hive")

                    # Condition 3: strong Momentum confirmation
                    if momentum_signal_confirmed:
                        should_convert_to_trailing = True
                        trigger_source.append("Momentum")

                    # Only execute STEP 2 if:
                    # - toggle is ON
                    # - we have at least reached STEP 1
                    # - TP not already cancelled
                    if not self.enable_step2_trailing and should_convert_to_trailing:
                        log_narration(
                            event_type="STEP2_DISABLED_SKIP",
                            details={
                                "order_id": order_id,
                                "symbol": symbol,
                                "rr_achieved": rr_achieved,
                                "trigger_source": trigger_source,
                            },
                            symbol=symbol,
                            venue="oanda",
                        )

                    if (
                        self.enable_step2_trailing
                        and should_convert_to_trailing
                        and not pos.get('tp_cancelled')
                        and pos.get('two_step_stage', 0) >= 1
                    ):
                        self.display.alert(
                            f"{'|'.join(trigger_source)} signal(s) for {symbol} - converting OCO to trailing SL",
                            "INFO",
                        )

                        try:
                            # Cancel the original OCO/TP order
                            cancel_resp = self.oanda.cancel_order(order_id)

                            log_narration(
                                event_type="TP_CANCEL_ATTEMPT",
                                details={
                                    "order_id": order_id,
                                    "trigger_source": trigger_source,
                                    "profit_atr": profit_atr_multiple,
                                    "cancel_response": cancel_resp,
                                },
                                symbol=symbol,
                                venue="oanda",
                            )

                            # Find the live trade and apply an adaptive trailing SL
                            trades = self.oanda.get_trades()
                            for t in trades:
                                trade_instrument = t.get('instrument') or t.get('symbol')
                                trade_id = (
                                    t.get('id')
                                    or t.get('tradeID')
                                    or t.get('trade_id')
                                )
                                if not trade_id:
                                    continue
                                if trade_instrument and trade_instrument.replace('.', '_').upper() == symbol:
                                    # Calculate adaptive trailing stop using SmartTrailingSystem
                                    if self.trailing_system and profit_atr_multiple > 0:
                                        atr_price = estimated_atr_pips * pip_size
                                        trail_distance = self.trailing_system.calculate_dynamic_trailing_distance(
                                            profit_atr_multiple=profit_atr_multiple,
                                            atr=atr_price,
                                            momentum_active=True,
                                        )

                                        # Ensure we at least lock some profit
                                        min_lock = self.min_trailing_lock_pips * pip_size
                                        if direction == 'BUY':
                                            raw_sl = current_price - trail_distance
                                            # never below BE+min_lock
                                            be_plus = entry_price + min_lock
                                            adaptive_sl = max(raw_sl, be_plus)
                                            # must still be below current price
                                            adaptive_sl = min(
                                                adaptive_sl,
                                                current_price - (1.0 * pip_size),
                                            )
                                        else:
                                            raw_sl = current_price + trail_distance
                                            be_minus = entry_price - min_lock
                                            adaptive_sl = min(raw_sl, be_minus)
                                            # must be above current price
                                            adaptive_sl = max(
                                                adaptive_sl,
                                                current_price + (1.0 * pip_size),
                                            )

                                        decimals = 3 if 'JPY' in symbol else 5
                                        adaptive_sl = round(adaptive_sl, decimals)
                                    else:
                                        adaptive_sl = pos.get('stop_loss')

                                    set_resp = self.oanda.set_trade_stop(trade_id, adaptive_sl)

                                    log_narration(
                                        event_type="TRAILING_SL_SET",
                                        details={
                                            "trade_id": trade_id,
                                            "order_id": order_id,
                                            "set_stop": adaptive_sl,
                                            "trail_distance_pips": (
                                                (current_price - adaptive_sl) / pip_size
                                                if direction == 'BUY'
                                                else (adaptive_sl - current_price) / pip_size
                                            ),
                                            "set_resp": set_resp,
                                            "trigger_source": trigger_source,
                                        },
                                        symbol=symbol,
                                        venue="oanda",
                                    )

                                    # Mark position as converted to trailing
                                    pos['tp_cancelled'] = True
                                    pos['tp_cancelled_timestamp'] = datetime.now(timezone.utc)
                                    pos['tp_cancel_source'] = trigger_source
                                    pos['two_step_stage'] = 2
                                    pos['stop_loss'] = adaptive_sl

                                    self.display.success(
                                        f"✅ STEP 2: TP cancelled and adaptive trailing SL set "
                                        f"for trade {trade_id} ({symbol})"
                                    )
                                    break

                        except Exception as e:
                            self.display.error(
                                f"Error during STEP 2 TP cancellation/trailing conversion for {symbol}: {e}"
                            )
                            log_narration(
                                event_type="TP_CANCEL_ERROR",
                                details={"order_id": order_id, "error": str(e)},
                                symbol=symbol,
                                venue="oanda",
                            )

                # Sleep short interval before next pass
                await asyncio.sleep(5)
            except Exception as e:
                self.display.error(f"TradeManager loop error: {e}")
                await asyncio.sleep(5)

                    # Use MomentumDetector from rbotzilla_golden_age.py
#                     if self.momentum_detector and profit_atr_multiple > 0:
#                         # Assume moderate trend and normal volatility for simple case
#                         # (In production, you'd query actual regime/volatility from ML modules)
#                         trend_strength = 0.7  # Moderate trend assumption
#                         market_cycle = 'BULL_MODERATE'  # Default assumption
#                         volatility = 1.0  # Normal volatility
# 
#                         has_momentum, momentum_strength = self.momentum_detector.detect_momentum(
#                             profit_atr_multiple=profit_atr_multiple,
#                             trend_strength=trend_strength,
#                             cycle=market_cycle,
#                             volatility=volatility
#                         )
# 
#                         if has_momentum:
#                             momentum_signal_confirmed = True
#                             self.display.info(f"Momentum detected: {momentum_strength:.2f}x strength for {symbol} (profit: {profit_atr_multiple:.2f}x ATR)", Colors.BRIGHT_GREEN)
#                             
#                             log_narration(
#                                 event_type="MOMENTUM_DETECTED",
#                                 details={
#                                     "symbol": symbol,
#                                     "profit_atr": profit_atr_multiple,
#                                     "momentum_strength": momentum_strength,
#                                     "order_id": order_id
#                                 },
#                                 symbol=symbol,
#                                 venue="momentum_detector"
#                             )
# 
#                     # Trigger TP cancellation if EITHER signal confirmed
#                     if hive_signal_confirmed or momentum_signal_confirmed:
#                         trigger_source = []
#                         if hive_signal_confirmed:
#                             trigger_source.append("Hive")
#                         if momentum_signal_confirmed:
#                             trigger_source.append("Momentum")
#                         
#                         self.display.alert(f"{'|'.join(trigger_source)} signal(s) detected for {symbol} - converting OCO to trailing SL", "INFO")
# 
#                         # Attempt to cancel TP order(s) associated with this OCO
#                         try:
#                             cancel_resp = self.oanda.cancel_order(order_id)
# 
#                             log_narration(
#                                 event_type="TP_CANCEL_ATTEMPT",
#                                 details={
#                                     "order_id": order_id,
#                                     "trigger_source": trigger_source,
#                                     "profit_atr": profit_atr_multiple,
#                                     "cancel_response": cancel_resp
#                                 },
#                                 symbol=symbol,
#                                 venue="oanda"
#                             )
# 
#                             # Find open trades for this symbol and set an initial trailing stop
#                             trades = self.oanda.get_trades()
#                             for t in trades:
#                                 trade_instrument = t.get('instrument') or t.get('symbol')
#                                 trade_id = t.get('id') or t.get('tradeID') or t.get('trade_id')
#                                 if not trade_id:
#                                     continue
#                                 if trade_instrument and trade_instrument.replace('.', '_').upper() == symbol:
#                                     # Calculate adaptive trailing stop using SmartTrailingSystem
#                                     if self.trailing_system and profit_atr_multiple > 0:
#                                         atr_price = estimated_atr_pips * pip_size
#                                         trail_distance = self.trailing_system.calculate_dynamic_trailing_distance(
#                                             profit_atr_multiple=profit_atr_multiple,
#                                             atr=atr_price,
#                                             momentum_active=True
#                                         )
#                                         
#                                         if direction == 'BUY':
#                                             new_sl = current_price - trail_distance
#                                         else:
#                                             new_sl = current_price + trail_distance
#                                         
#                                         # Ensure new SL is better than original
#                                         original_sl = pos.get('stop_loss')
#                                         if direction == 'BUY':
#                                             adaptive_sl = max(new_sl, original_sl)
#                                         else:
#                                             adaptive_sl = min(new_sl, original_sl)
#                                     else:
#                                         # Fallback: use existing stop_loss
#                                         adaptive_sl = pos.get('stop_loss')
#                                     
#                                     set_resp = self.oanda.set_trade_stop(trade_id, adaptive_sl)
# 
#                                     log_narration(
#                                         event_type="TRAILING_SL_SET",
#                                         details={
#                                             "trade_id": trade_id,
#                                             "order_id": order_id,
#                                             "set_stop": adaptive_sl,
#                                             "trail_distance_pips": (current_price - adaptive_sl) / pip_size if direction == 'BUY' else (adaptive_sl - current_price) / pip_size,
#                                             "set_resp": set_resp,
#                                             "trigger_source": trigger_source
#                                         },
#                                         symbol=symbol,
#                                         venue="oanda"
#                                     )
# 
#                                     # Mark position as having TP cancelled
#                                     pos['tp_cancelled'] = True
#                                     pos['tp_cancelled_timestamp'] = datetime.now(timezone.utc)
#                                     pos['tp_cancel_source'] = trigger_source
#                                     self.display.success(f"✅ TP cancelled and adaptive trailing SL set for trade {trade_id} ({symbol})")
#                                     break
# 
#                         except Exception as e:
#                             self.display.error(f"Error during TP cancellation/trailing conversion: {e}")
#                             log_narration(
#                                 event_type="TP_CANCEL_ERROR",
#                                 details={"order_id": order_id, "error": str(e)},
#                                 symbol=symbol,
#                                 venue="oanda"
#                             )
# 
#                 # Sleep short interval before next pass
#                 await asyncio.sleep(5)
#             except Exception as e:
#                 self.display.error(f"TradeManager loop error: {e}")
#                 await asyncio.sleep(5)
#     
    def _handle_position_closed(self, trade_id: str):
        """Handle a closed position"""
        if trade_id not in self.active_positions:
            return
        
        position = self.active_positions[trade_id]
        
        try:
            # Get trade details from OANDA
            trades = self.oanda.get_trades()
            
            # Assume win for now (we'd need to check actual closing price)
            # In real implementation, you'd query the closed trade details
            is_win = True  # Placeholder
            
            pnl = 50.0 if is_win else -20.0  # Placeholder values
            
            if is_win:
                self.wins += 1
                self.display.trade_win(
                    position['symbol'],
                    pnl,
                    f"Exit: {position['take_profit']:.5f} | R:R 3:1 achieved"
                )
            else:
                self.losses += 1
                self.display.trade_loss(
                    position['symbol'],
                    pnl,
                    f"Exit: {position['stop_loss']:.5f} | Stopped out"
                )
            
            # Remove from active positions
            del self.active_positions[trade_id]
            
            # Display stats
            self._display_stats()
            
        except Exception as e:
            self.display.error(f"Error handling closed position: {e}")
    
    def _display_stats(self):
        """Display current statistics"""
        win_rate = (self.wins / self.total_trades * 100) if self.total_trades > 0 else 0
        
        stats = {
            "Total Trades": str(self.total_trades),
            "Active Positions": str(len(self.active_positions)),
            "Wins / Losses": f"{self.wins} / {self.losses}",
            "Win Rate": f"{win_rate:.1f}%"
        }
        
        self.display.stats_panel(stats)
    
    async def run_trading_loop(self):
        """Main trading loop (environment-agnostic)"""
        self.is_running = True
        
        env_label = "PRACTICE" if self.environment == 'practice' else "LIVE"
        self.display.alert(f"Starting trading engine with {env_label} API...", "SUCCESS")
        self.display.alert(f"📊 Market Data: {env_label} OANDA API (real-time)", "INFO")
        self.display.alert(f"💰 Orders: {env_label} OANDA API", "INFO")
        print()
        
        trade_count = 0
        last_police_sweep = time.time()  # Track last Position Police sweep
        police_sweep_interval = 900  # 15 minutes (M15 charter compliance)
        
        # Start TradeManager background task
        trade_manager_task = asyncio.create_task(self.trade_manager_loop())
        
        while self.is_running:
            try:
                # AUTOMATED POSITION POLICE SWEEP (every 15 minutes)
                current_time = time.time()
                if current_time - last_police_sweep >= police_sweep_interval:
                    try:
                        self.display.info("🚓 Position Police", "sweep starting...", Colors.BRIGHT_YELLOW)
                        _rbz_force_min_notional_position_police()
                        last_police_sweep = current_time
                        self.display.success("✅ Position Police sweep complete")
                    except Exception as e:
                        self.display.error(f"❌ Position Police error: {e}")
                
                # Check existing positions
                self.check_positions()
                
                # Place new trade if we have less than 3 active positions
                if len(self.active_positions) < 3:
                    # ========================================================================
                    # FULL GATED SIGNAL GENERATION (Strategy Aggregator + ML + Hive Mind)
                    # ========================================================================
                    symbol = None
                    direction = None
                    final_confidence = 0.0
                    
                    for _candidate in self.trading_pairs:
                        try:
                            candles = self.oanda.get_historical_data(_candidate, count=120, granularity="M15")
                            
                            # STEP 1: Get base momentum signal
                            sig, conf, meta = generate_signal(_candidate, candles)  # returns ("BUY"/"SELL", confidence, meta) or (None, 0, {})
                            
                            if not sig or sig not in ("BUY", "SELL"):
                                continue
                            
                            # Get entry price for subsequent gates
                            price_data = self.get_current_price(_candidate)
                            entry_price = price_data['ask'] if sig == "BUY" else price_data['bid'] if price_data else 0
                            
                            # STEP 2: ML Regime Filter (if available)
                            if self.regime_detector and ML_AVAILABLE:
                                signal_data = {'action': sig.lower(), 'entry': entry_price}
                                ml_approved, ml_details = self.evaluate_signal_with_ml(_candidate, signal_data, candles)
                                if not ml_approved:
                                    self.display.warning(f"🔬 ML rejected {_candidate} {sig}: {ml_details.get('reason', 'low confidence')}")
                                    log_narration(
                                        event_type="ML_SIGNAL_REJECTED",
                                        details={"symbol": _candidate, "direction": sig, "reason": ml_details.get('reason', 'low confidence')},
                                        symbol=_candidate,
                                        venue="oanda"
                                    )
                                    continue  # Try next pair
                                else:
                                    self.display.success(f"🔬 ML approved {_candidate} {sig} (regime: {ml_details.get('regime', 'unknown')})")
                            
                            # STEP 3: Hive Mind Amplification (if available)
                            hive_boost = 1.0
                            if self.hive_mind and HIVE_AVAILABLE:
                                signal_data = {'action': sig.lower(), 'entry': entry_price, 'tag': 'momentum'}
                                amplified = self.amplify_signal_with_hive(_candidate, signal_data)
                                if amplified.get('hive_amplified'):
                                    hive_boost = 1.3  # 30% confidence boost
                                    hive_conf = amplified.get('hive_confidence', 0)
                                    self.display.success(f"🐝 Hive amplified {_candidate}: consensus {hive_conf:.1%}")
                                    log_narration(
                                        event_type="HIVE_AMPLIFICATION",
                                        details={"symbol": _candidate, "direction": sig, "hive_confidence": hive_conf, "boost": hive_boost},
                                        symbol=_candidate,
                                        venue="oanda"
                                    )
                            
                            # STEP 4: Compute final confidence
                            final_confidence = min(conf * hive_boost, 1.0)
                            
                            # STEP 5: Accept signal
                            symbol = _candidate
                            direction = sig
                            
                            try:
                                from util.confidence import format_confidence
                                conf_str = format_confidence(final_confidence)
                            except Exception:
                                conf_str = f"{final_confidence:.1%}"
                            
                            gates_used = []
                            if self.regime_detector and ML_AVAILABLE:
                                gates_used.append("ML")
                            if self.hive_mind and HIVE_AVAILABLE:
                                gates_used.append("HIVE")
                            gates_str = "+".join(gates_used) if gates_used else "MOMENTUM"
                            
                            self.display.success(f"✓ Signal: {symbol} {direction} (confidence: {conf_str}) [{gates_str}]")
                            break
                            
                        except Exception as e:
                            self.display.error(f"Signal error for {_candidate}: {e}")
                            continue
                    
                    if not symbol or not direction:
                        self.display.warning("No valid signals across pairs - skipping cycle")
                        await asyncio.sleep(self.min_trade_interval)
                        continue
                    
                    trade_id = self.place_trade(symbol, direction)
                    
                    if trade_id:
                        trade_count += 1
                    
                    self.display.divider()
                    print()
                
                # Wait before next trade (M15 Charter compliance)
                wait_minutes = self.min_trade_interval / 60
                self.display.alert(f"Waiting {wait_minutes:.0f} minutes before next trade (M15 Charter)...", "INFO")
                await asyncio.sleep(self.min_trade_interval)
                
            except KeyboardInterrupt:
                self.display.warning("\nStopping trading engine...")
                self.is_running = False
                break
            except Exception as e:
                self.display.error(f"Error in trading loop: {e}")
                await asyncio.sleep(10)
        
        self.display.section("SESSION COMPLETE")
        self._display_stats()
        # Cancel trade manager task
        try:
            trade_manager_task.cancel()
        except Exception:
            pass


async def main():
    """Main entry point - environment determined by API configuration"""
    import argparse
    
    parser = argparse.ArgumentParser(description='RBOTzilla Charter-Compliant OANDA Trading Engine')
    parser.add_argument('--env', '--environment', 
                       choices=['practice', 'live'], 
                       default='practice',
                       help='Trading environment (practice=demo, live=real money)')
    
    args = parser.parse_args()
    
    # Confirm LIVE mode with user
    if args.env == 'live':
        print("\n" + "="*60)
        print("⚠️  LIVE TRADING MODE - REAL MONEY AT RISK ⚠️")
        print("="*60)
        confirm = input("\nType 'CONFIRM LIVE' to proceed with live trading: ")
        if confirm != 'CONFIRM LIVE':
            print("Live trading cancelled.")
            return
        print("\n✅ Live trading confirmed. Initializing engine...\n")
    
    engine = OandaTradingEngine(environment=args.env)
    await engine.run_trading_loop()


if __name__ == "__main__":
    asyncio.run(main())

# ===== RBOTZILLA: POSITION POLICE (immutable min-notional) =====
try:
    from rick_charter import RickCharter
except Exception:
    class RickCharter: MIN_NOTIONAL_USD = 15000

def _rbz_usd_notional(instrument: str, units: float, price: float) -> float:
    try:
        base, quote = instrument.split("_",1)
        u = abs(float(units))
        p = float(price)
        if quote == "USD":      # e.g., GBP_USD
            return u * p
        if base == "USD":       # e.g., USD_JPY
            return u * 1.0
        return 0.0              # non-USD crosses (ignored by charter)
    except Exception:
        return 0.0

def _rbz_fetch_price(sess, acct: str, inst: str, tok: str):
    import requests
    try:
        r = sess.get(
            f"https://api-fxpractice.oanda.com/v3/accounts/{acct}/pricing",
            headers={"Authorization": f"Bearer {tok}"},
            params={"instruments": inst}, timeout=5,
        )
        return float(r.json()["prices"][0]["closeoutAsk"])
    except Exception:
        return None

def _rbz_force_min_notional_position_police():
    """
    AUTOMATED POSITION POLICE - GATED CHARTER ENFORCEMENT
    Closes any position < MIN_NOTIONAL_USD ($15,000)
    Runs: (1) On engine startup, (2) Every 15 minutes during trading loop
    PIN: 841921 | IMMUTABLE
    """
    import os, json, requests
    from datetime import datetime, timezone
    
    MIN_NOTIONAL = getattr(RickCharter, "MIN_NOTIONAL_USD", 15000)
    acct = os.environ.get("OANDA_PRACTICE_ACCOUNT_ID") or os.environ.get("OANDA_ACCOUNT_ID")
    tok  = os.environ.get("OANDA_PRACTICE_TOKEN") or os.environ.get("OANDA_TOKEN")
    if not acct or not tok:
        print('[RBZ_POLICE] skipped (no creds)'); return

    s = requests.Session()
    violations_found = 0
    violations_closed = 0
    
    # 1) fetch open positions
    r = s.get(
        f"https://api-fxpractice.oanda.com/v3/accounts/{acct}/openPositions",
        headers={"Authorization": f"Bearer {tok}"}, timeout=7,
    )
    
    positions = r.json().get("positions", [])
    timestamp = datetime.now(timezone.utc).isoformat()
    
    for pos in positions:
        inst = pos.get("instrument")
        long_u  = float(pos.get("long",{}).get("units","0"))
        short_u = float(pos.get("short",{}).get("units","0"))  # negative when short
        net = long_u + short_u
        if net == 0:
            continue

        avg = pos.get("long",{}).get("averagePrice") or pos.get("short",{}).get("averagePrice")
        price = float(avg) if avg else (_rbz_fetch_price(s, acct, inst, tok) or 0.0)
        notional = _rbz_usd_notional(inst, net, price)

        if 0 < notional < MIN_NOTIONAL:
            violations_found += 1
            violation_data = {
                "timestamp": timestamp,
                "event_type": "CHARTER_VIOLATION",
                "action": "POSITION_POLICE_AUTO_CLOSE",
                "details": {
                    "violation": "POSITION_BELOW_MIN_NOTIONAL",
                    "instrument": inst,
                    "net_units": net,
                    "side": "long" if net > 0 else "short",
                    "avg_price": price,
                    "notional_usd": round(notional, 2),
                    "min_required_usd": MIN_NOTIONAL,
                    "account": acct,
                    "enforcement": "GATED_LOGIC_AUTOMATIC"
                },
                "symbol": inst,
                "venue": "oanda"
            }
            
            # Log violation BEFORE closing
            print(json.dumps(violation_data))
            try:
                log_narration(**violation_data)
            except:
                pass  # Narration logger may not be available
            
            # Close entire side
            side = "long" if net > 0 else "short"
            payload = {"longUnits":"ALL"} if side=="long" else {"shortUnits":"ALL"}
            close_response = s.put(
                f"https://api-fxpractice.oanda.com/v3/accounts/{acct}/positions/{inst}/close",
                headers={"Authorization": f"Bearer {tok}", "Content-Type":"application/json"},
                data=json.dumps(payload), timeout=7,
            )
            
            if close_response.status_code == 200:
                violations_closed += 1
                close_data = {
                    "timestamp": timestamp,
                    "event_type": "POSITION_CLOSED",
                    "action": "CHARTER_ENFORCEMENT_SUCCESS",
                    "details": {
                        "instrument": inst,
                        "reason": "BELOW_MIN_NOTIONAL",
                        "status": "CLOSED_BY_POSITION_POLICE"
                    },
                    "symbol": inst,
                    "venue": "oanda"
                }
                print(json.dumps(close_data))
                try:
                    log_narration(**close_data)
                except:
                    pass
    
    # Summary logging
    if violations_found > 0:
        summary = {
            "timestamp": timestamp,
            "event_type": "POSITION_POLICE_SUMMARY",
            "details": {
                "violations_found": violations_found,
                "violations_closed": violations_closed,
                "enforcement": "GATED_LOGIC_AUTOMATIC",
                "min_notional_usd": MIN_NOTIONAL
            }
        }
        print(json.dumps(summary))
        try:
            log_narration(**summary)
        except:
            pass
            
# ===== /POSITION POLICE =====

# RBZ guard at import time
try:
    _rbz_force_min_notional_position_police()
except Exception as _e:
    print('[RBZ_POLICE] error', _e)

'''
