"""
PhoenixV2 Operations Module - The Surgeon

Background process that actively manages open positions:
1. Trailing Stops - Lock in profits by moving SL
2. Zombie Detection - Kill stagnant positions (> 4 hours, no movement)
3. Tourniquet Law - Close positions missing Stop Loss immediately
4. Winner's Lock - Move SL to breakeven when profit exceeds threshold
"""
import time
import threading
import logging
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

logger = logging.getLogger("Surgeon")


class Surgeon(threading.Thread):
    """
    The Position Surgeon.
    Runs in background, continuously monitoring and repairing positions.
    """
    
    def __init__(self, router):
        super().__init__()
        self.router = router
        self.running = False
        self.daemon = True
        
        # Configuration
        self.scan_interval = 30  # seconds between scans
        self.zombie_threshold_hours = 4  # Hours before position is "zombie"
        # trailing based on profit % thresholds
        self.breakeven_trigger_pct = 0.01  # 1% profit -> breakeven
        self.trailing_activation_pct = 0.02  # 2% profit -> start trailing
        self.trailing_tighten_pct = 0.032  # 3.2% profit -> tighten trailing
        # micro-trade kill threshold in units (absolute)
        self.micro_trade_threshold = 1000
        
        # State tracking
        self.position_entry_times: Dict[str, datetime] = {}
        self.position_high_prices: Dict[str, float] = {}
        self.position_low_prices: Dict[str, float] = {}
        self._last_heartbeat = datetime.utcnow()

    def run(self):
        """Main surgeon loop."""
        self.running = True
        logger.info("🩺 SURGEON ACTIVATED. Monitoring positions...")
        
        while self.running:
            try:
                self.scan_and_repair()
            except Exception as e:
                logger.error(f"Surgeon Error: {e}")
            # Heartbeat summary every 60 seconds
            try:
                if (datetime.utcnow() - self._last_heartbeat).total_seconds() >= 60:
                    try:
                        pstate = self.router.get_portfolio_state() if hasattr(self.router, 'get_portfolio_state') else {}
                        positions = pstate.get('open_positions', []) if pstate else []
                        total_unreal = sum([float(p.get('unrealizedPL', 0.0) or 0.0) for p in positions]) if positions else 0.0
                        logger.info(f"🩺 SURGEON REPORT: Monitoring {len(positions)} active trades. PnL: ${total_unreal:.2f}. Actions Taken: None")
                    except Exception:
                        pass
                    self._last_heartbeat = datetime.utcnow()
            except Exception:
                pass
            time.sleep(self.scan_interval)

    def stop(self):
        """Stop the surgeon."""
        self.running = False
        logger.info("🩺 SURGEON DEACTIVATED.")

    def scan_and_repair(self):
        """
        Main scan routine. Checks all positions and applies fixes.
        """
        # Use aggregated portfolio state across all brokers
        try:
            pstate = self.router.get_portfolio_state() if hasattr(self.router, 'get_portfolio_state') else {}
            positions = pstate.get('open_positions', []) if pstate else []
        except Exception:
            positions = []
        if not positions:
            return
        
        logger.debug(f"Surgeon scanning {len(positions)} positions...")
        
        for pos in positions:
            # Normalize different position shapes per broker
            if 'instrument' in pos:
                broker_type = 'OANDA'
            elif 'symbol' in pos and 'secType' in pos:
                broker_type = 'IBKR'
            elif 'currency' in pos or 'product_id' in pos:
                broker_type = 'COINBASE'
            else:
                broker_type = 'UNKNOWN'

            # For non-OANDA brokers, we do conservative checks only
            if broker_type != 'OANDA':
                # Only perform minimal checks for other brokers (presence of SL)
                current_sl = None
                try:
                    current_sl = pos.get('stopLoss') or pos.get('stop_loss') or pos.get('sl')
                except Exception:
                    current_sl = None
                if not current_sl:
                    logger.warning(f"🚨 TOURNIQUET ({broker_type}): {pos.get('symbol') or pos.get('currency') or pos.get('instrument')} has NO STOP LOSS! (Manual action required)")
                # Continue to next position
                continue
            trade_id = pos.get('id')
            instrument = pos.get('instrument')
            units = float(pos.get('currentUnits', 0))
            entry_price = float(pos.get('price', 0))
            unrealized_pl = float(pos.get('unrealizedPL', 0))
            
            # Get current SL/TP
            sl_order = pos.get('stopLossOrder', {})
            tp_order = pos.get('takeProfitOrder', {})
            current_sl = float(sl_order.get('price', 0)) if sl_order else None
            current_tp = float(tp_order.get('price', 0)) if tp_order else None
            
            # Track entry time for zombie detection
            if trade_id not in self.position_entry_times:
                open_time = pos.get('openTime', '')
                if open_time:
                    try:
                        self.position_entry_times[trade_id] = datetime.fromisoformat(open_time.replace('Z', '+00:00'))
                    except:
                        self.position_entry_times[trade_id] = datetime.utcnow()
                else:
                    self.position_entry_times[trade_id] = datetime.utcnow()
            
            # === RULE 1: TOURNIQUET LAW ===
            # Positions without SL must be closed immediately
            if not current_sl:
                logger.warning(f"🚨 TOURNIQUET: {instrument} has NO STOP LOSS! Closing immediately.")
                self.router.close_trade(trade_id)
                continue

            # === RULE 1b: MICRO-TRADE KILL ===
            # Kill tiny legacy or fractional trades that are below the minimum units threshold
            if abs(units) < self.micro_trade_threshold:
                logger.warning(f"🧹 SURGEON: Killing Micro-Trade {trade_id} ({units} units < {self.micro_trade_threshold}).")
                self.router.close_trade(trade_id)
                continue
            
            # === RULE 2: ZOMBIE DETECTION ===
            # Kill positions that have been open too long with minimal movement
            entry_time = self.position_entry_times.get(trade_id, datetime.utcnow())
            age_hours = (datetime.utcnow() - entry_time.replace(tzinfo=None)).total_seconds() / 3600
            
            if age_hours > self.zombie_threshold_hours:
                # Check if it's actually stagnant (small P&L)
                if abs(unrealized_pl) < 5:  # Less than $5 movement
                    logger.warning(f"🧟 ZOMBIE DETECTED: {instrument} open {age_hours:.1f}h with ${unrealized_pl:.2f} P&L. Closing.")
                    self.router.oanda.close_trade(trade_id)
                    continue
            
            # === RULE 3: WINNER'S LOCK (Breakeven) ===
            # Move SL to entry when profit exceeds threshold
            is_long = units > 0
            current_price = self.router.oanda.get_current_price(instrument)
            
            if current_price:
                # Compute per-position notional in USD to derive profit percentage
                try:
                    notional_usd = abs(units) * entry_price
                    # If USD is base, units are USD exposure already
                    if instrument.startswith('USD_') or instrument.startswith('USD'):
                        notional_usd = abs(units)
                except Exception:
                    notional_usd = abs(units) * entry_price if entry_price and abs(units) else 0.0
                profit_pct = (unrealized_pl / notional_usd) if notional_usd and notional_usd != 0 else 0.0
                
                # Check if we should move SL to breakeven
                if profit_pct >= self.breakeven_trigger_pct:
                    # Only if SL is not already at or better than entry
                    if is_long and current_sl < entry_price:
                        new_sl = entry_price + (2 * (0.01 if 'JPY' in instrument else 0.0001))  # Slight buffer above entry
                        logger.info(f"🔒 WINNER'S LOCK: {instrument} moving SL to breakeven {new_sl}")
                        self.router.oanda.modify_trade_sl(trade_id, new_sl)
                    elif not is_long and current_sl > entry_price:
                        new_sl = entry_price - (2 * (0.01 if 'JPY' in instrument else 0.0001))
                        logger.info(f"🔒 WINNER'S LOCK: {instrument} moving SL to breakeven {new_sl}")
                        self.router.oanda.modify_trade_sl(trade_id, new_sl)
            
            # === RULE 4: TRAILING STOP (profit pct-based using ATR) ===
            # Compute ATR for the instrument and set trailing distances
            if current_price and profit_pct >= self.trailing_activation_pct:
                try:
                    # fetch D15 candles for ATR
                    df = self.router.get_candles(instrument, timeframe='M15', limit=200)
                    atr = None
                    if df is not None and hasattr(df, 'iloc') and hasattr(df, 'columns') and all(c in df.columns for c in ['high', 'low', 'close']):
                        tr = pd.concat([
                            df['high'] - df['low'],
                            (df['high'] - df['close'].shift()).abs(),
                            (df['low'] - df['close'].shift()).abs()
                        ], axis=1).max(axis=1)
                        atr = float(tr.rolling(window=min(14, len(tr))).mean().iloc[-1]) if len(tr) > 0 else None
                    # Default distance fallback
                    if atr is None or atr == 0:
                        atr = 0.0025 if 'JPY' not in instrument else 0.30
                    # Determine trailing distance
                    if profit_pct >= self.trailing_tighten_pct:
                        trail_dist = atr * 0.5
                    elif profit_pct >= self.trailing_activation_pct:
                        trail_dist = atr * 1.0
                    else:
                        trail_dist = None
                    if trail_dist is not None:
                        if is_long:
                            ideal_sl = current_price - trail_dist
                            if ideal_sl > (current_sl or 0):
                                logger.info(f"📈 TRAILING: {instrument} moving SL {current_sl} -> {ideal_sl}")
                                self.router.close_trade # noop to appease linter
                                self.router.oanda.modify_trade_sl(trade_id, ideal_sl)
                        else:
                            ideal_sl = current_price + trail_dist
                            if ideal_sl < (current_sl or 0):
                                logger.info(f"📉 TRAILING: {instrument} moving SL {current_sl} -> {ideal_sl}")
                                self.router.oanda.modify_trade_sl(trade_id, ideal_sl)
                except Exception:
                    pass

    def force_scan(self):
        """Manually trigger a scan."""
        logger.info("🩺 SURGEON: Manual scan triggered")
        self.scan_and_repair()

    def get_status(self) -> Dict[str, Any]:
        """Get surgeon status report."""
        return {
            "running": self.running,
            "scan_interval": self.scan_interval,
            "zombie_threshold_hours": self.zombie_threshold_hours,
            "positions_tracked": len(self.position_entry_times),
            "rules_active": [
                "Tourniquet (No SL = Close)",
                "Zombie Detection (>4h stagnant)",
                "Winner's Lock (Breakeven @ 25 pips)",
                "Trailing Stop (15 pips distance)"
            ]
        }
