import unittest
from types import SimpleNamespace
from PhoenixV2.execution.router import BrokerRouter
from PhoenixV2.core.auth import AuthManager


class FakeOanda:
    def __init__(self, price=150.0, spread=0.0):
        self._price = price
        self._spread = spread

    def get_current_price(self, symbol):
        return self._price

    def get_current_bid_ask(self, symbol):
        return (self._price - self._spread / 2.0, self._price + self._spread / 2.0)

    def attach_sl_tp(self, order_id, sl, tp):
        return True

    def get_candles(self, symbol, timeframe='M15', limit=200):
        return None
    def place_order(self, order_packet):
        # emulate a simple order creation response
        # record the order for tests
        self.last_order = order_packet
        return True, {'order_id': 'fake_order', 'success': True}


class TestOandaUnits(unittest.TestCase):
    def setUp(self):
        self.auth = AuthManager()
        self.router = BrokerRouter(self.auth)
        # set fake oanda and ensure stub connection
        self.router.oanda = FakeOanda(price=110.0, spread=0.1)
        self.router.ibkr = None
        self.router.coinbase = None

    def test_usd_base_formats(self):
        order = {'symbol': 'USD_JPY', 'direction': 'BUY', 'notional_value': 15000}
        success, resp = self.router._execute_oanda(order)
        # For fake oanda successful place order returns something; ensure units were used as notional
        # We can't access internal units directly, but we can check the router doesn't fail when requested
        self.assertTrue(success or isinstance(resp, dict))
        # Ensure units were computed as equal to notional for USD base
        self.assertEqual(self.router.oanda.last_order.get('units'), 15000)

    def test_usd_slash_format(self):
        order = {'symbol': 'USD/JPY', 'direction': 'BUY', 'notional_value': 15000}
        success, resp = self.router._execute_oanda(order)
        self.assertTrue(success or isinstance(resp, dict))
        self.assertEqual(self.router.oanda.last_order.get('units'), 15000)

    def test_usd_concatenated(self):
        order = {'symbol': 'USDJPY', 'direction': 'BUY', 'notional_value': 15000}
        success, resp = self.router._execute_oanda(order)
        self.assertTrue(success or isinstance(resp, dict))
        self.assertEqual(self.router.oanda.last_order.get('units'), 15000)

    def test_quote_usd_pairs(self):
        order = {'symbol': 'EUR_USD', 'direction': 'BUY', 'notional_value': 15000, 'entry': 1.1, 'sl': 1.05}
        success, resp = self.router._execute_oanda(order)
        self.assertTrue(success or isinstance(resp, dict))


if __name__ == '__main__':
    unittest.main()
