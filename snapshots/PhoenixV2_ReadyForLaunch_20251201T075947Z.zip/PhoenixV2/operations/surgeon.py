"""
PhoenixV2 Operations Module - The Surgeon

Background process that actively manages open positions:
1. Trailing Stops - Lock in profits by moving SL
2. Zombie Detection - Kill stagnant positions (> 4 hours, no movement)
3. Tourniquet Law - Close positions missing Stop Loss immediately
4. Winner's Lock - Move SL to breakeven when profit exceeds threshold
"""
import time
import threading
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

logger = logging.getLogger("Surgeon")


class Surgeon(threading.Thread):
    """
    The Position Surgeon.
    Runs in background, continuously monitoring and repairing positions.
    """
    
    def __init__(self, router):
        super().__init__()
        self.router = router
        self.running = False
        self.daemon = True
        
        # Configuration
        self.scan_interval = 30  # seconds between scans
        self.zombie_threshold_hours = 4  # Hours before position is "zombie"
        self.trailing_activation_pips = 20  # Pips profit before trailing activates
        self.trailing_distance_pips = 15  # Pips behind price for trailing stop
        self.breakeven_trigger_pips = 25  # Pips profit to move SL to breakeven
        
        # State tracking
        self.position_entry_times: Dict[str, datetime] = {}
        self.position_high_prices: Dict[str, float] = {}
        self.position_low_prices: Dict[str, float] = {}
        self._last_heartbeat = datetime.utcnow()

    def run(self):
        """Main surgeon loop."""
        self.running = True
        logger.info("🩺 SURGEON ACTIVATED. Monitoring positions...")
        
        while self.running:
            try:
                self.scan_and_repair()
            except Exception as e:
                logger.error(f"Surgeon Error: {e}")
            # Heartbeat summary every 60 seconds
            try:
                if (datetime.utcnow() - self._last_heartbeat).total_seconds() >= 60:
                    try:
                        pstate = self.router.get_portfolio_state() if hasattr(self.router, 'get_portfolio_state') else {}
                        positions = pstate.get('open_positions', []) if pstate else []
                        total_unreal = sum([float(p.get('unrealizedPL', 0.0) or 0.0) for p in positions]) if positions else 0.0
                        logger.info(f"🩺 SURGEON REPORT: Monitoring {len(positions)} active trades. PnL: ${total_unreal:.2f}. Actions Taken: None")
                    except Exception:
                        pass
                    self._last_heartbeat = datetime.utcnow()
            except Exception:
                pass
            time.sleep(self.scan_interval)

    def stop(self):
        """Stop the surgeon."""
        self.running = False
        logger.info("🩺 SURGEON DEACTIVATED.")

    def scan_and_repair(self):
        """
        Main scan routine. Checks all positions and applies fixes.
        """
        # Use aggregated portfolio state across all brokers
        try:
            pstate = self.router.get_portfolio_state() if hasattr(self.router, 'get_portfolio_state') else {}
            positions = pstate.get('open_positions', []) if pstate else []
        except Exception:
            positions = []
        if not positions:
            return
        
        logger.debug(f"Surgeon scanning {len(positions)} positions...")
        
        for pos in positions:
            # Normalize different position shapes per broker
            if 'instrument' in pos:
                broker_type = 'OANDA'
            elif 'symbol' in pos and 'secType' in pos:
                broker_type = 'IBKR'
            elif 'currency' in pos or 'product_id' in pos:
                broker_type = 'COINBASE'
            else:
                broker_type = 'UNKNOWN'

            # For non-OANDA brokers, we do conservative checks only
            if broker_type != 'OANDA':
                # Only perform minimal checks for other brokers (presence of SL)
                current_sl = None
                try:
                    current_sl = pos.get('stopLoss') or pos.get('stop_loss') or pos.get('sl')
                except Exception:
                    current_sl = None
                if not current_sl:
                    logger.warning(f"🚨 TOURNIQUET ({broker_type}): {pos.get('symbol') or pos.get('currency') or pos.get('instrument')} has NO STOP LOSS! (Manual action required)")
                # Continue to next position
                continue
            trade_id = pos.get('id')
            instrument = pos.get('instrument')
            units = float(pos.get('currentUnits', 0))
            entry_price = float(pos.get('price', 0))
            unrealized_pl = float(pos.get('unrealizedPL', 0))
            
            # Get current SL/TP
            sl_order = pos.get('stopLossOrder', {})
            tp_order = pos.get('takeProfitOrder', {})
            current_sl = float(sl_order.get('price', 0)) if sl_order else None
            current_tp = float(tp_order.get('price', 0)) if tp_order else None
            
            # Track entry time for zombie detection
            if trade_id not in self.position_entry_times:
                open_time = pos.get('openTime', '')
                if open_time:
                    try:
                        self.position_entry_times[trade_id] = datetime.fromisoformat(open_time.replace('Z', '+00:00'))
                    except:
                        self.position_entry_times[trade_id] = datetime.utcnow()
                else:
                    self.position_entry_times[trade_id] = datetime.utcnow()
            
            # === RULE 1: TOURNIQUET LAW ===
            # Positions without SL must be closed immediately
            if not current_sl:
                logger.warning(f"🚨 TOURNIQUET: {instrument} has NO STOP LOSS! Closing immediately.")
                self.router.oanda.close_trade(trade_id)
                continue
            
            # === RULE 2: ZOMBIE DETECTION ===
            # Kill positions that have been open too long with minimal movement
            entry_time = self.position_entry_times.get(trade_id, datetime.utcnow())
            age_hours = (datetime.utcnow() - entry_time.replace(tzinfo=None)).total_seconds() / 3600
            
            if age_hours > self.zombie_threshold_hours:
                # Check if it's actually stagnant (small P&L)
                if abs(unrealized_pl) < 5:  # Less than $5 movement
                    logger.warning(f"🧟 ZOMBIE DETECTED: {instrument} open {age_hours:.1f}h with ${unrealized_pl:.2f} P&L. Closing.")
                    self.router.oanda.close_trade(trade_id)
                    continue
            
            # === RULE 3: WINNER'S LOCK (Breakeven) ===
            # Move SL to entry when profit exceeds threshold
            is_long = units > 0
            current_price = self.router.oanda.get_current_price(instrument)
            
            if current_price:
                pip_value = 0.0001 if "JPY" not in instrument else 0.01
                
                if is_long:
                    profit_pips = (current_price - entry_price) / pip_value
                else:
                    profit_pips = (entry_price - current_price) / pip_value
                
                # Check if we should move SL to breakeven
                if profit_pips >= self.breakeven_trigger_pips:
                    # Only if SL is not already at or better than entry
                    if is_long and current_sl < entry_price:
                        new_sl = entry_price + (2 * pip_value)  # Slight buffer above entry
                        logger.info(f"🔒 WINNER'S LOCK: {instrument} moving SL to breakeven {new_sl}")
                        self.router.oanda.modify_trade_sl(trade_id, new_sl)
                    elif not is_long and current_sl > entry_price:
                        new_sl = entry_price - (2 * pip_value)
                        logger.info(f"🔒 WINNER'S LOCK: {instrument} moving SL to breakeven {new_sl}")
                        self.router.oanda.modify_trade_sl(trade_id, new_sl)
            
            # === RULE 4: TRAILING STOP ===
            # Trail the stop loss behind price as profit increases
            if current_price and profit_pips >= self.trailing_activation_pips:
                if is_long:
                    # For longs, trail SL below current price
                    ideal_sl = current_price - (self.trailing_distance_pips * pip_value)
                    if ideal_sl > current_sl:
                        logger.info(f"📈 TRAILING: {instrument} moving SL {current_sl:.5f} -> {ideal_sl:.5f}")
                        self.router.oanda.modify_trade_sl(trade_id, ideal_sl)
                else:
                    # For shorts, trail SL above current price
                    ideal_sl = current_price + (self.trailing_distance_pips * pip_value)
                    if ideal_sl < current_sl:
                        logger.info(f"📉 TRAILING: {instrument} moving SL {current_sl:.5f} -> {ideal_sl:.5f}")
                        self.router.oanda.modify_trade_sl(trade_id, ideal_sl)

    def force_scan(self):
        """Manually trigger a scan."""
        logger.info("🩺 SURGEON: Manual scan triggered")
        self.scan_and_repair()

    def get_status(self) -> Dict[str, Any]:
        """Get surgeon status report."""
        return {
            "running": self.running,
            "scan_interval": self.scan_interval,
            "zombie_threshold_hours": self.zombie_threshold_hours,
            "positions_tracked": len(self.position_entry_times),
            "rules_active": [
                "Tourniquet (No SL = Close)",
                "Zombie Detection (>4h stagnant)",
                "Winner's Lock (Breakeven @ 25 pips)",
                "Trailing Stop (15 pips distance)"
            ]
        }
