import unittest
from PhoenixV2.gate.risk_gate import RiskGate
from PhoenixV2.core.auth import AuthManager


class RiskGateTest(unittest.TestCase):
    def test_rejects_notional_exceeding_risk_limit(self):
        auth = AuthManager()
        gate = RiskGate(auth)
        # Setup portfolio with nav 10000
        p_state = {'total_nav': 10000}
        # Entry 100, sl 95 -> risk_pct 0.05 -> allowed_notional = 10000*0.02/0.05 = 4000
        signal = {'symbol': 'EUR_USD', 'direction': 'BUY', 'notional_value': 10000, 'entry': 100.0, 'sl': 95.0, 'timeframe': 'M15', 'sl': 95.0, 'tp': 160.0}
        is_valid, reason = gate.validate_signal(signal, current_positions=None, portfolio_state=p_state)
        self.assertFalse(is_valid)
        self.assertEqual(reason, 'NOTIONAL_EXCEEDS_RISK_LIMIT')

if __name__ == '__main__':
    unittest.main()
