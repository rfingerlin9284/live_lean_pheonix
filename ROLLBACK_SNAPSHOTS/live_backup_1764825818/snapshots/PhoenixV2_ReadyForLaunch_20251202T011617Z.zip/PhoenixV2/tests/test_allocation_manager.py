import unittest
import pandas as pd
from PhoenixV2.gate.allocation_manager import AllocationManager
from PhoenixV2.core.state_manager import StateManager
from types import SimpleNamespace


class TestAllocationManager(unittest.TestCase):
    def setUp(self):
        self.state = StateManager('/tmp/test_phoenix_state.json')
        self.am = AllocationManager(self.state)

    def _make_df(self, atr_values, length=150):
        import numpy as np
        idx = pd.date_range('2025-01-01', periods=length, freq='15T')
        # build df where high-low equals atr_values for each row
        base = 100.0
        highs = [base + v for v in atr_values]
        lows = [base - v for v in atr_values]
        closes = [base + (v / 10.0) for v in atr_values]
        opens = [base for _ in atr_values]
        return pd.DataFrame({'open': opens, 'high': highs, 'low': lows, 'close': closes}, index=idx)

    def test_calculate_size_calm_market_increases(self):
        # Make df where last ATR is 0.5 and average over 100 is 1.0 -> vol_ratio 0.5 -> calm -> multiplier 1.5
        atr_vals = [1.0] * 120
        atr_vals[-1] = 0.5
        df = self._make_df(atr_vals, length=len(atr_vals))
        size = self.am.calculate_size('test', 10000, market_data={'df': df})
        self.assertGreater(size, 10000)

    def test_calculate_size_chaos_market_decreases(self):
        # make df where last ATR is 3.0 and average over 100 is 1.0 -> vol_ratio 3.0 -> chaos -> multiplier 0.5
        atr_vals = [1.0] * 120
        atr_vals[-1] = 3.0
        df = self._make_df(atr_vals, length=len(atr_vals))
        size = self.am.calculate_size('test', 10000, market_data={'df': df})
        self.assertLess(size, 10000)

if __name__ == '__main__':
    unittest.main()
import tempfile
import json
import unittest
from PhoenixV2.gate.allocation_manager import AllocationManager
from PhoenixV2.core.state_manager import StateManager
from pathlib import Path


def _make_state(tmpdir):
    state_file = Path(tmpdir) / 'tmp_state.json'
    sm = StateManager(str(state_file))
    # hack set weights directly
    sm._learning['strategy_weights'] = {'test_strat': 2.0}
    sm._persist_learning()
    return sm


class AllocationManagerTestCase(unittest.TestCase):
    def test_allocation_manager_respects_weights_and_caps(self, tmpdir=None):
        if tmpdir is None:
            tmpdir = tempfile.mkdtemp()
        sm = _make_state(tmpdir)
        am = AllocationManager(sm)
        base = 10000
        adjusted = am.calculate_size('test_strat', base)
        self.assertGreaterEqual(adjusted, base * 0.5)
        self.assertLessEqual(adjusted, base * 3.0)
        # With weight 2.0 it should be doubled or capped
        self.assertTrue(adjusted == base * 2.0 or adjusted == base * 3.0)

    def test_allocation_manager_capped_by_risk(self, tmpdir=None):
        if tmpdir is None:
            tmpdir = tempfile.mkdtemp()
        sm = _make_state(tmpdir)
        am = AllocationManager(sm)
        base = 10000
        portfolio_state = {'total_nav': 10000}
        # Entry 100, SL 95 -> risk_pct 0.05 -> allowed_notional = 10000*0.02/0.05 = 4000
        adjusted = am.calculate_size('test_strat', base, portfolio_state, entry=100.0, sl=95.0)
        self.assertLessEqual(adjusted, 4000)

    def test_profit_multiplier_scaling(self):
        sm = StateManager('/tmp/test_phoenix_state.json')
        am = AllocationManager(sm)
        base = 10000
        # Simulate a day that is up $1300 -> multiplier should be 1 + (1300 - 300)/1000 = 1 + 1.0 = 2.0 capped
        p_state = {'daily_start_balance': 10000.0, 'current_balance': 11300.0}
        adjusted = am.calculate_size('test', base, portfolio_state=p_state)
        # Because default weight is 1.0 and vol_multiplier = 1.0, adjusted should be base * profit multiplier but capped by max_multiplier
        self.assertLessEqual(adjusted, base * am.max_multiplier)
        # Because profit multiplier capping is 2.0, final adjusted should be >= base (and potentially doubled)
        self.assertGreaterEqual(adjusted, base * 1.0)

if __name__ == '__main__':
    unittest.main()
