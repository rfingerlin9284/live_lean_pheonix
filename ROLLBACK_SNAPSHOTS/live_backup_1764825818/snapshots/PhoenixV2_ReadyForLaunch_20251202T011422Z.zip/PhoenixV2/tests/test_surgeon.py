import unittest
from types import SimpleNamespace
from PhoenixV2.operations.surgeon import Surgeon
import pandas as pd


class FakeOanda:
    def __init__(self, price=1.0):
        self.price = price
        self.modified = []

    def get_current_price(self, instrument):
        return self.price

    def modify_trade_sl(self, trade_id, new_sl):
        self.modified.append((trade_id, new_sl))
        return True

    def get_candles(self, instrument, timeframe='M15', limit=200):
        # return a small DataFrame with ATR-like values
        idx = pd.date_range('2025-01-01', periods=20, freq='15T')
        df = pd.DataFrame({'open': [1.0]*20, 'high':[1.002]*20, 'low':[0.998]*20, 'close':[1.0]*20}, index=idx)
        return df


class FakeRouter:
    def __init__(self, positions):
        self.positions = positions
        self.closed = []
        self.oanda = FakeOanda(price=1.05)

    def get_portfolio_state(self):
        return {'open_positions': self.positions}

    def close_trade(self, trade_id):
        self.closed.append(trade_id)
        return True

    def get_candles(self, instrument, timeframe='M15', limit=200):
        return self.oanda.get_candles(instrument, timeframe, limit)


class SurgeonTest(unittest.TestCase):
    def test_kill_micro_trade_and_trail_big(self):
        # micro trade (small units) and a larger trade
        micro = {
            'id': 'micro1',
            'instrument': 'AUD_USD',
            'currentUnits': 61,
            'price': 0.65489,
            'unrealizedPL': 0.0,
            'stopLossOrder': {'price': 0.65},
            'takeProfitOrder': None,
            'openTime': '2025-12-01T00:00:00Z'
        }
        large = {
            'id': 'big1',
            'instrument': 'AUD_USD',
            'currentUnits': 14660,
            'price': 0.65489,
            'unrealizedPL': 200.0,  # in USD
            'stopLossOrder': {'price': 0.65},
            'takeProfitOrder': None,
            'openTime': '2025-12-01T00:00:00Z'
        }
        router = FakeRouter([micro, large])
        surgeon = Surgeon(router)
        # set micro threshold to 1000 per the new rules
        surgeon.micro_trade_threshold = 1000
        # run scan_and_repair once
        surgeon.scan_and_repair()
        # assert micro closed
        self.assertIn('micro1', router.closed)
        # assert large not closed
        self.assertNotIn('big1', router.closed)


if __name__ == '__main__':
    unittest.main()
