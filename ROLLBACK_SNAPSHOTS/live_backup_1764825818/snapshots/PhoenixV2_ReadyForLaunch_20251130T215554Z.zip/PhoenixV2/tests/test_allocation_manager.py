import tempfile
import json
import unittest
from PhoenixV2.gate.allocation_manager import AllocationManager
from PhoenixV2.core.state_manager import StateManager
from pathlib import Path


def _make_state(tmpdir):
    state_file = Path(tmpdir) / 'tmp_state.json'
    sm = StateManager(str(state_file))
    # hack set weights directly
    sm._learning['strategy_weights'] = {'test_strat': 2.0}
    sm._persist_learning()
    return sm


class AllocationManagerTestCase(unittest.TestCase):
    def test_allocation_manager_respects_weights_and_caps(self, tmpdir=None):
        if tmpdir is None:
            tmpdir = tempfile.mkdtemp()
        sm = _make_state(tmpdir)
        am = AllocationManager(sm)
        base = 10000
        adjusted = am.calculate_size('test_strat', base)
        self.assertGreaterEqual(adjusted, base * 0.5)
        self.assertLessEqual(adjusted, base * 3.0)
        # With weight 2.0 it should be doubled or capped
        self.assertTrue(adjusted == base * 2.0 or adjusted == base * 3.0)

    def test_allocation_manager_capped_by_risk(self, tmpdir=None):
        if tmpdir is None:
            tmpdir = tempfile.mkdtemp()
        sm = _make_state(tmpdir)
        am = AllocationManager(sm)
        base = 10000
        portfolio_state = {'total_nav': 10000}
        # Entry 100, SL 95 -> risk_pct 0.05 -> allowed_notional = 10000*0.02/0.05 = 4000
        adjusted = am.calculate_size('test_strat', base, portfolio_state, entry=100.0, sl=95.0)
        self.assertLessEqual(adjusted, 4000)

if __name__ == '__main__':
    unittest.main()
