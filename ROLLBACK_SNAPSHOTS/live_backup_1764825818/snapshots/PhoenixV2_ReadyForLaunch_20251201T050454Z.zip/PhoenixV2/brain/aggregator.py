"""
PhoenixV2 Brain Module - Strategy Aggregator

The central brain that coordinates HiveMind, WolfPack strategies,
and QuantHedge regime-based adjustments. Outputs a unified trade recommendation.
"""
import time
import os
from pathlib import Path
import logging
from typing import Dict, Any, Optional
from PhoenixV2.execution.router import BrokerRouter

from .hive_mind import HiveMindBridge
from .wolf_pack import WolfPack
from PhoenixV2.core.state_manager import StateManager
from .quant_hedge import QuantHedgeRules, RegimeDetector
# Import MarketRegime from the logic detector to normalize regimes across detectors
from logic.regime_detector import MarketRegime

logger = logging.getLogger("Brain")


class StrategyBrain:
    """
    The Unified Strategy Aggregator.
    
    Collects signals from:
    1. HiveMind (ML-based 3:1 filter)
    2. WolfPack (5-strategy voting)
    
    Applies:
    - QuantHedge regime-based size/stop adjustments
    
    Outputs a single, consolidated trade recommendation.
    """
    
    

    def __init__(self, router: Optional[BrokerRouter] = None):
        self.hive_mind = HiveMindBridge()
        # instantiate state manager for learning-driven strategy weights
        self.state_manager = StateManager(str(Path(__file__).resolve().parents[1] / 'core' / 'phoenix_state.json'))
        self.wolf_pack = WolfPack(state_manager=self.state_manager)
        self.quant_hedge = QuantHedgeRules()
        self.regime_detector = RegimeDetector()
        self.min_rr = 3.0
        self.default_notional = 16000  # Passes $15k institutional floor
        self.router = router

    def get_signal(self, symbol: Optional[str] = None, market_data: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Returns a trade signal or None if no valid setup.
        
        Signal Format:
        {
            "symbol": "EUR_USD",
            "direction": "BUY" | "SELL",
            "timeframe": "H1",
            "notional_value": 16000,
            "sl": float,
            "tp": float,
            "confidence": 0.0-1.0,
            "source": "HiveMind" | "WolfPack" | "Consensus"
        }
        """
        # 1. Detect current regime first
        regime, volatility = self.regime_detector.detect()
        # Normalize regime to MarketRegime string (bull/bear/sideways/crash/triage)
        regime = self._normalize_regime(regime)
        # Map MarketRegime to quant hedge regime format expected by QuantHedgeRules
        quant_regime = 'TRIAGE'
        if regime == MarketRegime.BULL.value:
            quant_regime = 'BULL_STRONG'
        elif regime == MarketRegime.BEAR.value:
            quant_regime = 'BEAR_STRONG'
        elif regime == MarketRegime.SIDEWAYS.value:
            quant_regime = 'SIDEWAYS'
        elif regime == MarketRegime.CRASH.value:
            quant_regime = 'CRISIS'

        hedge_params = self.quant_hedge.get_hedge_params(quant_regime, volatility)
        
        # 2. Try HiveMind first (it has built-in 3:1 filter)
        hive_signal = self.hive_mind.fetch_inference()
        
        if hive_signal:
            # Convert HiveMind format to standard signal format
            signal = self._normalize_hive_signal(hive_signal)
            # Apply hedge adjustments
            signal = self.quant_hedge.adjust_signal(signal)
            return signal
        
        # 2. If HiveMind has no signal, check WolfPack
        # WolfPack needs market data - for now we pass empty dict
        # If no market_data provided, try to fetch via router.get_candles if router and symbol available
        md = market_data or {}
        if not md and self.router and symbol:
            try:
                df = self.router.get_candles(symbol, timeframe='M15', limit=200)
                if df is not None:
                    md = {"price": float(df.iloc[-1]['close']), "timeframe": 'M15', "df": df}
                    # If it's a crypto instrument, fetch correlation asset candles (SPX) for correlation-based wolves
                    try:
                        # Only add correlation data for crypto instruments
                        if '-' in symbol or 'BTC' in symbol or 'ETH' in symbol:
                            corr_index = os.getenv('CORRELATION_INDEX', 'SPX500_USD')
                            # Get hourly candles for correlation analysis
                            spx_df = self.router.get_candles(corr_index, timeframe='H1', limit=200)
                            if spx_df is not None:
                                md['spx_df'] = spx_df
                                md['btc_df'] = df
                    except Exception:
                        pass
            except Exception:
                md = {}

        wolf_consensus = self.wolf_pack.get_consensus(md or {})
        
        if wolf_consensus["direction"] != "HOLD":
            logger.info(f"🐺 WOLFPACK CONSENSUS: {wolf_consensus['direction']} ({wolf_consensus['confidence']:.0%})")
            # WolfPack can be used as a signal generator here - in the brain we do a deeper pass
            # Enforce higher thresholds for Crypto (sniper mode for safety): require confidence >= 0.85
            if symbol and ('BTC' in symbol or 'ETH' in symbol or ('-' in symbol and symbol.split('-')[0] in ['BTC', 'ETH'])):
                if wolf_consensus.get('confidence', 0.0) < 0.85:
                    logger.info("🐺 WOLFPACK Crypto consensus below sniper threshold - ignoring")
                    return None
            # Return a minimal consensus signal; in real life, a deeper strategy would populate SL/TP
            strategy_name = wolf_consensus.get('top_strategy') or wolf_consensus.get('strategy') or wolf_consensus.get('top_strat')
            contributing = wolf_consensus.get('strategy_votes', {})
            return {
                "symbol": symbol or "UNSPECIFIED",
                "direction": wolf_consensus['direction'],
                "timeframe": (market_data or {}).get('timeframe', 'M15'),
                "notional_value": self.default_notional,
                "entry": (market_data or {}).get('price', 0),
                "sl": (market_data or {}).get('sl'),
                "tp": (market_data or {}).get('tp'),
                "confidence": wolf_consensus.get('confidence', 0.0),
                "strategy": strategy_name,
                "contributing_strategies": contributing,
                "source": "WolfPack"
            }
            pass
        
        return None

    def _normalize_hive_signal(self, hive_signal: Dict[str, Any]) -> Dict[str, Any]:
        """Convert HiveMind signal format to standard output format."""
        return {
            "symbol": hive_signal.get("pair"),
            "direction": hive_signal.get("direction"),
            "timeframe": hive_signal.get("timeframe", "M15"),
            "notional_value": self.default_notional,
            "entry": hive_signal.get("entry"),
            "sl": hive_signal.get("sl"),
            "tp": hive_signal.get("tp"),
            "confidence": hive_signal.get("confidence", 0.75),
            "source": "HiveMind",
            "ml_note": hive_signal.get("ml_note", "")
        }

    def _normalize_regime(self, reg) -> str:
        """Normalize various regime outputs to known MarketRegime values.

        Accepts strings or enum values from detectors and returns MarketRegime.value string.
        """
        # If it's an enum, just return its value
        try:
            if hasattr(reg, 'value'):
                return reg.value
        except Exception:
            pass

        if not isinstance(reg, str):
            return MarketRegime.TRIAGE.value

        r = reg.lower()
        if 'bull' in r:
            return MarketRegime.BULL.value
        if 'bear' in r:
            return MarketRegime.BEAR.value
        if 'crash' in r or 'crisis' in r:
            return MarketRegime.CRASH.value
        if 'side' in r or 'sideways' in r:
            return MarketRegime.SIDEWAYS.value
        return MarketRegime.TRIAGE.value

    def _validate_rr(self, signal: Dict[str, Any]) -> bool:
        """Validate Risk/Reward ratio."""
        entry = signal.get('entry', 0)
        sl = signal.get('sl', 0)
        tp = signal.get('tp', 0)
        
        if entry == 0 or abs(entry - sl) == 0:
            return False
            
        risk = abs(entry - sl)
        reward = abs(tp - entry)
        rr = reward / risk
        
        if rr < self.min_rr:
            logger.debug(f"RR FAIL: {signal.get('symbol')} RR={rr:.2f}")
            return False
        
        return True
