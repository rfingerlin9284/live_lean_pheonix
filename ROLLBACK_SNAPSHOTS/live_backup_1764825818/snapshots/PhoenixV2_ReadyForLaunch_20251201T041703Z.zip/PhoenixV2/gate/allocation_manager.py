"""
Allocation Manager
Calculates adjusted position size based on strategy weights and base notional.
"""
from typing import Dict, Any, Optional
import pandas as pd
from PhoenixV2.core.state_manager import StateManager
from PhoenixV2.config.charter import Charter


class AllocationManager:
    """Manage strategy-based allocation size adjustments.

    Uses StateManager to fetch strategy weights, applies caps, and returns an adjusted notional.
    """

    def __init__(self, state_manager: StateManager):
        self.state_manager = state_manager
        # hard caps - conservative defaults
        self.max_multiplier = 3.0
        self.min_multiplier = 0.5

    def calculate_size(self, strategy_name: str, base_notional: float, portfolio_state: Optional[Dict[str, Any]] = None, entry: Optional[float] = None, sl: Optional[float] = None, market_data: Optional[Dict[str, Any]] = None) -> float:
        """Return adjusted notional based on strategy weight and portfolio constraints.

        Caps the size between min and max multipliers and also ensures the result meets
        the charter minimum notional requirements.
        """
        try:
            weight = float(self.state_manager.get_strategy_weight(strategy_name) or 1.0)
        except Exception:
            weight = 1.0

        # 2. Volatility Regime (Soros Filter)
        vol_multiplier = 1.0
        try:
            if market_data and isinstance(market_data.get('df', None), pd.DataFrame):
                df = market_data['df']
                # Compute True Range and ATR Rolling 100
                tr = pd.concat([
                    df['high'] - df['low'],
                    (df['high'] - df['close'].shift()).abs(),
                    (df['low'] - df['close'].shift()).abs()
                ], axis=1).max(axis=1)
                current_atr = float(tr.iloc[-1])
                avg_atr = float(tr.rolling(100).mean().iloc[-1]) if len(tr) >= 100 else float(tr.mean())
                if avg_atr and avg_atr > 0:
                    vol_ratio = current_atr / avg_atr
                    if vol_ratio < 0.8:
                        vol_multiplier = 1.5
                    elif vol_ratio > 1.5:
                        vol_multiplier = 0.5
        except Exception:
            vol_multiplier = 1.0

        adjusted = base_notional * weight * vol_multiplier
        if adjusted > base_notional * self.max_multiplier:
            adjusted = base_notional * self.max_multiplier
        if adjusted < base_notional * self.min_multiplier:
            adjusted = base_notional * self.min_multiplier

        # Ensure adjusted size respects charter min_size for live/paper
        try:
            min_size = Charter.get_min_size(self.state_manager.get_state().get('mode') == 'LIVE')
        except Exception:
            min_size = Charter.MIN_NOTIONAL_PAPER

        if adjusted < min_size:
            adjusted = min_size

        # If we have portfolio state and entry/sl, cap the size based on charter risk
        try:
            nav = float(portfolio_state.get('total_nav', 0.0)) if portfolio_state else 0.0
            if nav > 0 and entry and sl and entry != 0:
                # Risk per unit in price terms
                risk_per_unit = abs(entry - sl)
                # risk percent relative to entry price
                risk_pct = (risk_per_unit / abs(entry)) if entry != 0 else 0.0
                if risk_pct > 0:
                    allowed_notional = (nav * Charter.MAX_RISK_PER_TRADE) / risk_pct
                else:
                    allowed_notional = (nav * Charter.MAX_RISK_PER_TRADE)
                # cap adjusted to not exceed allowed_notional
                if adjusted > allowed_notional:
                    adjusted = allowed_notional
        except Exception:
            pass

        return float(adjusted)
